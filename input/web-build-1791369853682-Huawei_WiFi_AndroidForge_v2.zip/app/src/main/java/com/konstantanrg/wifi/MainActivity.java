package com.konstantanrg.wifi;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSuggestion;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 10;
    private WifiManager wifi;
    private LinearLayout networks;
    private TextView status;
    private BroadcastReceiver scanReceiver;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        wifi = (WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
        buildUi();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
        } else scan();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 24, 28, 24);

        TextView title = new TextView(this);
        title.setText("Wi-Fi"); title.setTextSize(28); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("Поиск сетей..."); status.setTextSize(16); status.setPadding(0, 18, 0, 18);
        root.addView(status);

        Button refresh = new Button(this);
        refresh.setText("Обновить сети"); refresh.setOnClickListener(v -> scan());
        root.addView(refresh, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(this);
        networks = new LinearLayout(this); networks.setOrientation(LinearLayout.VERTICAL);
        sv.addView(networks);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView manual = new TextView(this);
        manual.setText("Подключение к сети вручную"); manual.setTextSize(20); manual.setPadding(0, 20, 0, 8);
        root.addView(manual);
        EditText ssid = new EditText(this); ssid.setHint("Имя сети (SSID)");
        root.addView(ssid);
        EditText pass = new EditText(this); pass.setHint("Пароль"); pass.setInputType(0x81);
        root.addView(pass);
        Button connect = new Button(this); connect.setText("Подключиться");
        connect.setOnClickListener(v -> connect(ssid.getText().toString().trim(), pass.getText().toString()));
        root.addView(connect);
        setContentView(root);
    }

    private void scan() {
        if (wifi == null) { status.setText("Wi-Fi недоступен"); return; }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            status.setText("Нужно разрешение на доступ к местоположению для поиска сетей"); return;
        }
        try {
            if (!wifi.isWifiEnabled()) wifi.setWifiEnabled(true);
            if (scanReceiver != null) unregisterReceiver(scanReceiver);
            scanReceiver = new BroadcastReceiver() {
                @Override public void onReceive(Context c, Intent i) { showNetworks(); }
            };
            registerReceiver(scanReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
            wifi.startScan();
            status.setText("Поиск сетей...");
        } catch (Exception e) { status.setText("Ошибка поиска: " + e.getMessage()); }
    }

    private void showNetworks() {
        try {
            List<ScanResult> list = new ArrayList<>(wifi.getScanResults());
            Collections.sort(list, (a,b) -> Integer.compare(b.level, a.level));
            networks.removeAllViews();
            String current = wifi.getConnectionInfo() != null ? wifi.getConnectionInfo().getSSID() : "";
            status.setText("Найдено сетей: " + list.size());
            for (ScanResult r : list) {
                if (r.SSID == null || r.SSID.length() == 0) continue;
                Button btn = new Button(this);
                String label = r.SSID + "   " + r.level + " dBm";
                if (r.SSID.equals(current.replace("\"", ""))) label += "  ✓";
                btn.setText(label);
                btn.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                btn.setOnClickListener(v -> askPasswordAndConnect(r.SSID, r.capabilities));
                networks.addView(btn, new LinearLayout.LayoutParams(-1, -2));
            }
        } catch (SecurityException e) { status.setText("Нет доступа к списку Wi-Fi: " + e.getMessage()); }
    }

    private void askPasswordAndConnect(String ssid, String caps) {
        EditText pass = new EditText(this);
        pass.setHint(caps.contains("WEP") ? "Пароль WEP" : "Пароль Wi-Fi (оставьте пустым для открытой сети)");
        pass.setInputType(0x81);
        new android.app.AlertDialog.Builder(this).setTitle(ssid).setView(pass)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Подключиться", (d,w) -> connect(ssid, pass.getText().toString()))
            .show();
    }

    private void connect(String ssid, String password) {
        if (ssid == null || ssid.isEmpty()) { toast("Укажите SSID"); return; }
        try {
            WifiNetworkSuggestion.Builder b = new WifiNetworkSuggestion.Builder().setSsid(ssid);
            if (password != null && !password.isEmpty()) {
                if (password.length() < 8) { toast("Пароль WPA2 должен быть не короче 8 символов"); return; }
                b.setWpa2Passphrase(password);
            }
            List<WifiNetworkSuggestion> suggestions = new ArrayList<>();
            suggestions.add(b.build());
            int result = wifi.addNetworkSuggestions(suggestions);
            if (result == WifiManager.STATUS_NETWORK_SUGGESTIONS_SUCCESS) {
                status.setText("Запрос подключения отправлен: " + ssid);
                toast("Подключение к " + ssid + " запрошено");
            } else if (result == WifiManager.STATUS_NETWORK_SUGGESTIONS_ERROR_ADD_DUPLICATE) {
                toast("Эта сеть уже добавлена");
            } else {
                toast("Ошибка Wi-Fi: " + result);
            }
        } catch (Exception e) { toast("Не удалось подключиться: " + e.getMessage()); }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override protected void onDestroy() {
        if (scanReceiver != null) { try { unregisterReceiver(scanReceiver); } catch (Exception ignored) {} }
        super.onDestroy();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_LOCATION && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) scan();
        else status.setText("Разрешение на поиск Wi-Fi не предоставлено");
    }
}
