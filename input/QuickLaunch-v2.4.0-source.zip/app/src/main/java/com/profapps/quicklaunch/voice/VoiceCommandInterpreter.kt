package com.profapps.quicklaunch.voice

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.widget.Toast
import com.profapps.quicklaunch.data.AppEntry
import com.profapps.quicklaunch.providers.AppIndex
import com.profapps.quicklaunch.providers.ContactsProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Parses voice transcripts into actionable commands:
 * - "open [app]" → launches the app
 * - "call [contact]" / "text [contact]" → calls or texts the contact
 * - "play [song/artist]" → plays in default music app or searches
 * - "search [query]" / "[question]" → web search with optional TTS response
 * - "what is [query]" / "who is [query]" → answer the question (search → TTS)
 *
 * Integrates with device settings for default apps (music, phone, etc).
 */
class VoiceCommandInterpreter(
    private val context: Context,
    private val appIndex: AppIndex,
    private val contactsProvider: ContactsProvider,
    defaultMusicAppPackage: String? = null,
    private val onExecute: (Intent) -> Unit = { context.startActivity(it) },
) {
    private var textToSpeech: TextToSpeech? = null
    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    var defaultMusicAppPackage = defaultMusicAppPackage
        set(value) {
            field = value
        }

    init {
        // Initialize TTS for voice responses
        runCatching {
            textToSpeech = TextToSpeech(context) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    textToSpeech?.language = Locale.getDefault()
                }
            }
        }
    }

    /**
     * Parse and execute a voice command. Returns a human-readable response
     * and optionally speaks it aloud if it's an answer/search result.
     */
    suspend fun executeCommand(transcript: String): String {
        val command = transcript.trim().lowercase()

        return when {
            // Pattern: "open [app]"
            command.startsWith("open ") -> executeOpenApp(command.removePrefix("open ").trim())

            // Pattern: "call [contact]" or "phone [contact]"
            command.startsWith("call ") || command.startsWith("phone ") -> {
                val contact = command.removePrefix("call ").removePrefix("phone ").trim()
                executeCall(contact)
            }

            // Pattern: "text [contact]" or "message [contact]" or "sms [contact]"
            command.startsWith("text ") || command.startsWith("message ") || command.startsWith("sms ") -> {
                val contact = command
                    .removePrefix("text ")
                    .removePrefix("message ")
                    .removePrefix("sms ")
                    .trim()
                executeText(contact)
            }

            // Pattern: "play [song/artist]"
            command.startsWith("play ") -> {
                val query = command.removePrefix("play ").trim()
                executePlay(query)
            }

            // Pattern: "search [query]"
            command.startsWith("search ") -> {
                val query = command.removePrefix("search ").trim()
                executeWebSearch(query)
            }

            // Pattern: "what is [query]" or "who is [query]" or "when [query]" etc
            command.startsWith("what ") || command.startsWith("who ") ||
            command.startsWith("when ") || command.startsWith("where ") ||
            command.startsWith("why ") || command.startsWith("how ") -> {
                // These are question patterns; search and speak the answer
                executeQuestionSearch(command)
            }

            // Default: treat as web search
            else -> executeWebSearch(command)
        }
    }

    private suspend fun executeOpenApp(appName: String): String {
        val apps = appIndex.getApps()
        val match = apps.find { it.label.lowercase().contains(appName) }
            ?: apps.find { it.label.lowercase().startsWith(appName) }

        return if (match != null) {
            launchApp(match)
            "Opening ${match.label}"
        } else {
            "App \"$appName\" not found"
        }
    }

    private suspend fun executeCall(contactName: String): String {
        val contact = runCatching {
            contactsProvider.search(
                com.profapps.quicklaunch.search.SearchQuery(
                    raw = contactName,
                    hint = com.profapps.quicklaunch.search.CommandHint.None,
                ),
            ).firstOrNull { it.id.startsWith("contact:") }
        }.getOrNull()

        return if (contact != null) {
            val phoneUri = Uri.parse("tel:${contact.id.removePrefix("contact:")}")
            onExecute(Intent(Intent.ACTION_CALL, phoneUri))
            "Calling ${contact.title}"
        } else {
            "Contact \"$contactName\" not found"
        }
    }

    private suspend fun executeText(contactName: String): String {
        val contact = runCatching {
            contactsProvider.search(
                com.profapps.quicklaunch.search.SearchQuery(
                    raw = contactName,
                    hint = com.profapps.quicklaunch.search.CommandHint.None,
                ),
            ).firstOrNull { it.id.startsWith("contact:") }
        }.getOrNull()

        return if (contact != null) {
            val smsUri = Uri.parse("smsto:${contact.id.removePrefix("contact:")}")
            onExecute(Intent(Intent.ACTION_SENDTO, smsUri))
            "Messaging ${contact.title}"
        } else {
            "Contact \"$contactName\" not found"
        }
    }

    private suspend fun executePlay(query: String): String {
        // If a default music app is set, use it
        val musicAppPackage = defaultMusicAppPackage
            ?: getSystemDefaultMusicApp()

        if (musicAppPackage != null && isAppInstalled(musicAppPackage)) {
            val intent = context.packageManager.getLaunchIntentForPackage(musicAppPackage)
            if (intent != null) {
                // Try to pass the search query to the music app
                intent.putExtra("query", query)
                intent.putExtra("search", query)
                onExecute(intent)
                return "Playing \"$query\" in music app"
            }
        }

        // Fallback: web search for the song
        return executeWebSearch("$query song")
    }

    private suspend fun executeWebSearch(query: String): String {
        val searchUri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
        val intent = Intent(Intent.ACTION_VIEW, searchUri)
        onExecute(intent)
        return "Searching for \"$query\""
    }

    private suspend fun executeQuestionSearch(question: String): String {
        // For questions, we'd ideally get a direct answer (from a service or API),
        // but for now, do a web search and speak the query back
        // In a real implementation, this could use a QA API or parse search results
        val response = "Searching for: $question"
        speak(response)
        executeWebSearch(question)
        return response
    }

    private fun launchApp(app: AppEntry) {
        val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent != null) {
            onExecute(intent)
        }
    }

    private fun isAppInstalled(packageName: String): Boolean {
        return runCatching {
            context.packageManager.getApplicationInfo(packageName, 0)
            true
        }.getOrDefault(false)
    }

    private fun getSystemDefaultMusicApp(): String? {
        // Try common music apps in order of popularity
        val musicApps = listOf(
            "com.spotify.music",
            "com.apple.android.music",
            "com.google.android.apps.mediashell",
            "com.amazon.music",
            "com.deezer.android.app",
        )
        return musicApps.firstOrNull { isAppInstalled(it) }
    }

    fun speak(text: String) {
        if (textToSpeech == null) return
        runCatching {
            _isSpeaking.value = true
            textToSpeech?.speak(
                text,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "tts_id_${System.currentTimeMillis()}",
            )
            // Note: ideally listen to onDone callback; for now assume quick responses
            runCatching {
                Thread.sleep(text.length * 50L) // rough estimate
                _isSpeaking.value = false
            }
        }
    }

    fun release() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
    }
}
