# Quick Launch v2.2.0

This release makes the app store-releasable (package rename off the reserved
`com.example` namespace), fixes the assistant redirect button and a real
crash in the results list, tightens the recents list, and adds a small new
provider.

## Fixed

- **Digital assistant redirect button did nothing.** The "Set as assistant"
  action cast the Compose context directly to `Activity`
  (`context as? Activity ?: return`). When that cast came back null — which
  it can, since Compose contexts aren't always the raw Activity — the whole
  handler bailed out silently, including the settings-page fallback that was
  supposed to catch exactly this case. Replaced with `Context.findActivity()`,
  which unwraps the `ContextWrapper` chain, so the button now always either
  opens the system role dialog or falls back to the assistant settings page.
- **Random crash while searching.** Search results are sorted by relevance
  score first and grouped into category headers only as a side effect —
  categories are not guaranteed to be contiguous. When the same category
  appeared twice in one result list (e.g. an app result, then a web result,
  then another app result), the results list rendered two identical
  `"h:apps"` header rows, and Compose's `LazyColumn` throws
  `IllegalArgumentException: Key ... was already used` on a duplicate key —
  crashing the palette. Header row keys now fold in their position, so
  repeated categories no longer collide; every other row keeps its original
  stable key so scrolling/animations are unaffected.
- Removed a stale sample chip ("ask why is the sky blue") left over from the
  Ask AI feature removed in v2.1.0 — it silently fell through to a plain web
  search with no indication why.

## Changed

- **Package renamed:** `com.example.quicklaunch` → `com.profapps.quicklaunch`.
  `com.example.*` is a reserved namespace and Play Console rejects
  submissions under it outright — this was a hard blocker for releasing the
  app anywhere, not a cosmetic detail. This is a breaking change for existing
  installs: because the applicationId changed, this build cannot be
  installed as an update over an old `com.example.quicklaunch` install; users
  need to uninstall the old one first (on-device settings/recents don't
  carry over, since nothing here touches a server).
- **Recents trimmed to the latest 2** (was 5) — the longer list was pushing
  pinned apps and the "Try" suggestions further down for little benefit.

## Added

- **Quick info provider** — small, zero-permission answers, same interaction
  as the calculator:
  - `battery` → current charge percentage and charging state
  - `time` → current time
  - `date` → today's date

  Tap any of these to copy the value. Toggle it off in *Settings → Search
  providers* like any other provider.

## Upgrading

Existing installs on `2.1.x` or earlier: uninstall the old build first, then
install this one — the applicationId change means Android treats it as a
different app. Device-level permissions (overlay, contacts, media) will need
to be re-granted.

## Changes

- `AndroidManifest.xml`, `build.gradle.kts`: `com.example.quicklaunch` →
  `com.profapps.quicklaunch` (namespace, applicationId, and every source
  reference)
- `AssistantRoleHelper.kt`: added `Context.findActivity()`
- `SettingsScreen.kt`: assistant-role button now uses `findActivity()` with a
  guaranteed fallback
- `OverlayPanel.kt`: `rowKey()` now takes a position index to keep header
  keys unique; switched `items()` → `itemsIndexed()`
- `PaletteController.kt`: recents shown in the empty state capped at 2
  (`MAX_EMPTY_STATE_RECENTS`)
- `PaletteRows.kt`: removed the stale "ask …" sample chip
- New: `QuickInfoProvider.kt`, wired into `AppContainer`, `ProviderIds`,
  `SettingsViewModel.PROVIDERS`, and `strings.xml`
- Version bumped: `2.1.1` (versionCode 6) → **`2.2.0`** (versionCode 7)

---

**Full Changelog**: v2.1.1...v2.2.0
