# Minification is disabled for debug and release builds in this project.
# If you enable R8 in the future, the default optimize rules plus AndroidX
# consumer rules are sufficient for this app's reflective surface.
