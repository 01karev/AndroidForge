package com.profapps.quicklaunch.ranking

import com.profapps.quicklaunch.search.ranking.FuzzyMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FuzzyMatcherTest {

    private fun score(query: String, target: String): Float? =
        FuzzyMatcher.match(query, target)?.score

    @Test
    fun `exact match scores highest`() {
        val exact = score("chrome", "chrome")
        val prefix = score("chrome", "chrome beta")
        assertEquals(1.0f, exact!!, 0.0001f)
        assertTrue(prefix!! < exact)
    }

    @Test
    fun `prefix beats word-start beats substring beats subsequence`() {
        val prefix = score("chro", "chrome browser")
        val wordStart = score("br", "chrome browser")
        val substring = score("rome", "chrome")
        val fuzzy = score("cbr", "chrome browser")
        assertTrue(prefix!! > wordStart!!)
        assertTrue(wordStart > substring!!)
        assertTrue(substring > fuzzy!!)
    }

    @Test
    fun `word start matching splits on delimiters and camel case`() {
        assertNotNull(FuzzyMatcher.match("cs", "ChromeStore"))
        assertNotNull(FuzzyMatcher.match("wif", "Wi-Fi Settings"))
        assertNotNull(FuzzyMatcher.match("ap", "app_manager"))
    }

    @Test
    fun `non matches return null`() {
        assertNull(score("xyz", "chrome"))
        assertNull(score("calculator", "wifi"))
    }

    @Test
    fun `empty query never matches`() {
        assertNull(score("", "chrome"))
        assertNull(score("  ", "chrome"))
    }

    @Test
    fun `usage boost lifts score but clamps at one`() {
        val plain = FuzzyMatcher.match("ch", "chrome")!!
        val boosted = FuzzyMatcher.match("chrome", "chrome", usageBoost = 0.5f)!!
        assertTrue(boosted.score > plain.score)
        assertEquals(1.0f, boosted.score, 0.0001f)
    }

    @Test
    fun `pinned boost applies`() {
        val plain = FuzzyMatcher.match("ch", "chrome")!!
        val pinned = FuzzyMatcher.match("ch", "chrome", pinnedBoost = 0.18f)!!
        assertTrue(pinned.score > plain.score)
    }

    @Test
    fun `subsequence honours character order`() {
        assertNotNull(score("gml", "gmail"))
        // 'm' appears before 'a' in gmail but after in reverse order query
        assertNull(score("mlg", "gmail"))
    }

    @Test
    fun `deterministic across calls`() {
        val first = FuzzyMatcher.match("set", "Settings")
        val second = FuzzyMatcher.match("set", "Settings")
        assertEquals(first, second)
    }

    @Test
    fun `tokenizer splits camel humps`() {
        val tokens = FuzzyMatcher.tokenize("quicklaunchpad")
        assertEquals(listOf("quicklaunchpad"), tokens)
        val humped = FuzzyMatcher.tokenize("quickLaunchPad")
        assertEquals(listOf("quick", "launch", "pad"), humped)
    }

    @Test
    fun `multi word query requires all tokens`() {
        assertTrue(FuzzyMatcher.wordStartMatch("ch set", "chrome settings"))
        assertFalse(FuzzyMatcher.wordStartMatch("ch zz", "chrome settings"))
    }
}
