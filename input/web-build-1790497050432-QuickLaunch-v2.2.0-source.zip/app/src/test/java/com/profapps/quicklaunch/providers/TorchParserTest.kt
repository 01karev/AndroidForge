package com.profapps.quicklaunch.providers

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure JVM tests for the flashlight query parser: which torch actions a
 * palette query should offer. The hardware toggle is Android-only and is
 * covered by manual QA, not unit tests.
 */
class TorchParserTest {

    @Test
    fun `plain flashlight word offers both on and off`() {
        val parsed = TorchParser.parse("flashlight")
        assertEquals(TorchParser.Parsed(includeOn = true, includeOff = true), parsed)
    }

    @Test
    fun `torch word offers both`() {
        val parsed = TorchParser.parse("torch")
        assertTrue(parsed!!.includeOn)
        assertTrue(parsed.includeOff)
    }

    @Test
    fun `flash word offers both`() {
        val parsed = TorchParser.parse("flash")
        assertTrue(parsed!!.includeOn)
        assertTrue(parsed.includeOff)
    }

    @Test
    fun `flashlight off offers only off`() {
        val parsed = TorchParser.parse("flashlight off")
        assertFalse(parsed!!.includeOn)
        assertTrue(parsed.includeOff)
    }

    @Test
    fun `turn off flashlight offers only off regardless of order`() {
        val parsed = TorchParser.parse("turn off flashlight")
        assertFalse(parsed!!.includeOn)
        assertTrue(parsed.includeOff)
    }

    @Test
    fun `flashlight on offers only on`() {
        val parsed = TorchParser.parse("flashlight on")
        assertTrue(parsed!!.includeOn)
        assertFalse(parsed.includeOff)
    }

    @Test
    fun `toggle means on only`() {
        val parsed = TorchParser.parse("flashlight toggle")
        assertTrue(parsed!!.includeOn)
        assertFalse(parsed.includeOff)
    }

    @Test
    fun `case and whitespace are ignored`() {
        val parsed = TorchParser.parse("  FLASHLIGHT   OFF ")
        assertFalse(parsed!!.includeOn)
        assertTrue(parsed.includeOff)
    }

    @Test
    fun `unrelated queries return null`() {
        assertNull(TorchParser.parse("hello world"))
        assertNull(TorchParser.parse(""))
        assertNull(TorchParser.parse("   "))
    }

    @Test
    fun `flash as a standalone word matches even inside a phrase`() {
        // Word-equality matching means "flash drive repair" still offers the
        // flashlight switch — intended KRunner-style behaviour, documented here.
        val parsed = TorchParser.parse("flash drive repair")
        assertTrue(parsed!!.includeOn)
        assertTrue(parsed.includeOff)
    }

    @Test
    fun `word equality is required - no substring matches`() {
        assertNull(TorchParser.parse("flashing"))
        assertNull(TorchParser.parse("torchlight"))
    }

    @Test
    fun `very long queries are rejected`() {
        assertNull(TorchParser.parse("flashlight " + "x".repeat(60)))
    }
}
