package com.profapps.quicklaunch.search

import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeProvider(
    override val id: String,
    override val displayName: String = id,
    private val delayMs: Long = 0,
    private val results: (String) -> List<SearchResult> = { emptyList() },
) : SearchProvider {
    var callCount = 0
        private set

    override suspend fun search(query: SearchQuery): List<SearchResult> {
        callCount++
        if (delayMs > 0) delay(delayMs)
        return results(query.raw)
    }
}

private fun result(id: String, title: String, score: Float) = SearchResult(
    id = id,
    title = title,
    score = score,
    category = ResultCategory.ACTIONS,
    action = { ActionResult.Dismiss },
)

class SearchEngineTest {

    @Test
    fun `merges providers and sorts by score descending`() = runTest {
        val engine = SearchEngine(
            providers = listOf(
                FakeProvider("a") { listOf(result("a1", "Alpha low", 0.2f)) },
                FakeProvider("b") { listOf(result("b1", "Beta high", 0.9f)) },
                FakeProvider("c") { listOf(result("c1", "Gamma mid", 0.5f)) },
            ),
        )
        val results = engine.search("query")
        assertEquals(listOf("Beta high", "Gamma mid", "Alpha low"), results.map { it.title })
    }

    @Test
    fun `disabled providers are never called`() = runTest {
        val disabled = FakeProvider("disabled") { listOf(result("d1", "Should not appear", 1f)) }
        val enabled = FakeProvider("enabled") { listOf(result("e1", "Enabled result", 0.5f)) }
        val engine = SearchEngine(listOf(disabled, enabled), isEnabled = { id -> id != "disabled" })
        val results = engine.search("q")
        assertEquals(0, disabled.callCount)
        assertEquals(1, enabled.callCount)
        assertEquals(1, results.size)
    }

    @Test
    fun `slow provider is cut off by timeout without failing others`() = runTest {
        val slow = FakeProvider("slow", delayMs = 5_000) { listOf(result("s1", "Slow", 1f)) }
        val fast = FakeProvider("fast") { listOf(result("f1", "Fast", 0.5f)) }
        val engine = SearchEngine(listOf(slow, fast), defaultTimeoutMs = 100)
        val results = engine.search("q")
        assertEquals(listOf("Fast"), results.map { it.title })
    }

    @Test
    fun `cancelling the search cancels providers`() = runTest {
        val slow = FakeProvider("slow", delayMs = 10_000)
        val engine = SearchEngine(listOf(slow), defaultTimeoutMs = 60_000)
        val job = launch { engine.search("q") }
        advanceTimeBy(50)
        assertTrue(slow.callCount == 1)
        job.cancel()
        advanceUntilIdle()
        assertTrue(job.isCancelled)
    }

    @Test
    fun `exception in provider does not break the whole search`() = runTest {
        val broken = object : SearchProvider {
            override val id = "broken"
            override val displayName = "broken"
            override suspend fun search(query: SearchQuery): List<SearchResult> {
                throw IllegalStateException("boom")
            }
        }
        val healthy = FakeProvider("healthy") { listOf(result("h1", "Healthy", 0.4f)) }
        val engine = SearchEngine(listOf(broken, healthy))
        val results = engine.search("q")
        assertEquals(listOf("Healthy"), results.map { it.title })
    }

    @Test
    fun `duplicates by id are removed`() = runTest {
        val engine = SearchEngine(
            listOf(
                FakeProvider("a") { listOf(result("dup", "First", 0.9f)) },
                FakeProvider("b") { listOf(result("dup", "Second", 0.8f)) },
            ),
        )
        val results = engine.search("q")
        assertEquals(1, results.size)
        assertEquals("First", results.first().title)
    }

    @Test
    fun `blank query short-circuits`() = runTest {
        val provider = FakeProvider("a") { listOf(result("x", "X", 1f)) }
        val engine = SearchEngine(listOf(provider))
        assertEquals(0, engine.search("").size)
        assertEquals(0, engine.search("   ").size)
        assertEquals(0, provider.callCount)
    }

    @Test
    fun `empty result rows are filtered out`() = runTest {
        val engine = SearchEngine(
            listOf(
                FakeProvider("a") { listOf(result("ok", "Fine", 0.5f), result("", "", 0.9f)) },
            ),
        )
        val results = engine.search("q")
        assertEquals(1, results.size)
    }
}
