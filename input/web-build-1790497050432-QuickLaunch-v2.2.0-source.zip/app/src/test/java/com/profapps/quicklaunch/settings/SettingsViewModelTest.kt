package com.profapps.quicklaunch.settings

import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.data.QuickLaunchSettings
import com.profapps.quicklaunch.data.RecentEntry
import com.profapps.quicklaunch.data.RecentsRepository
import com.profapps.quicklaunch.data.SettingsRepository
import com.profapps.quicklaunch.ui.settings.PermissionChecker
import com.profapps.quicklaunch.ui.settings.SettingsViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestWatcher
import org.junit.runner.Description
import java.io.File

private class FakePermissionChecker(
    var overlay: Boolean = false,
    var contacts: Boolean = false,
    var notifications: Boolean = true,
    var files: Boolean = false,
) : PermissionChecker {
    override fun isOverlayGranted(): Boolean = overlay
    override fun isContactsGranted(): Boolean = contacts
    override fun isNotificationsGranted(): Boolean = notifications
    override fun isFilesGranted(): Boolean = files
}

/** Redirects viewModelScope (Main dispatcher) to the test dispatcher. */
@OptIn(ExperimentalCoroutinesApi::class)
class MainDispatcherRule : TestWatcher() {
    override fun starting(description: Description) {
        Dispatchers.setMain(UnconfinedTestDispatcher())
    }

    override fun finished(description: Description) {
        Dispatchers.resetMain()
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class SettingsViewModelTest {

    @get:Rule
    val mainDispatcherRule: MainDispatcherRule = MainDispatcherRule()

    private lateinit var settingsRepo: SettingsRepository
    private lateinit var recentsRepo: RecentsRepository
    private lateinit var checker: FakePermissionChecker
    private val files = mutableListOf<File>()

    @Before
    fun setUp() {
        val settingsFile = File.createTempFile("ql-vm-settings", ".preferences_pb")
        val recentsFile = File.createTempFile("ql-vm-recents", ".preferences_pb")
        files += settingsFile
        files += recentsFile
        val dispatcher = UnconfinedTestDispatcher()
        val scope = CoroutineScope(dispatcher + SupervisorJob())
        settingsRepo = SettingsRepository(
            androidx.datastore.preferences.core.PreferenceDataStoreFactory.create(
                scope = scope,
                produceFile = { settingsFile },
            ),
            scope,
        )
        recentsRepo = RecentsRepository(
            androidx.datastore.preferences.core.PreferenceDataStoreFactory.create(
                scope = scope,
                produceFile = { recentsFile },
            ),
        )
        checker = FakePermissionChecker()
    }

    @After
    fun tearDown() {
        files.forEach { it.delete() }
    }

    @Test
    fun `provider toggle flows through to settings state`() = runTest {
        val vm = SettingsViewModel(settingsRepo, recentsRepo, checker)
        advanceUntilIdle()
        assertTrue(vm.settings.value.isProviderEnabled(ProviderIds.WEB))
        vm.setProviderEnabled(ProviderIds.WEB, false)
        advanceUntilIdle()
        assertFalse(vm.settings.value.isProviderEnabled(ProviderIds.WEB))
    }

    @Test
    fun `permission banner reflects checker state`() = runTest {
        val vm = SettingsViewModel(settingsRepo, recentsRepo, checker)
        advanceUntilIdle()
        assertFalse(vm.overlayPermissionGranted)
        checker.overlay = true
        vm.refresh()
        assertTrue(vm.overlayPermissionGranted)
    }

    @Test
    fun `bubble trigger and files permission state flow through`() = runTest {
        val vm = SettingsViewModel(settingsRepo, recentsRepo, checker)
        advanceUntilIdle()
        assertFalse(vm.filesPermissionGranted)
        assertFalse(vm.settings.value.bubbleTriggerEnabled)

        checker.files = true
        vm.refresh()
        assertTrue(vm.filesPermissionGranted)

        vm.setBubbleTrigger(true)
        advanceUntilIdle()
        assertTrue(vm.settings.value.bubbleTriggerEnabled)
    }

    @Test
    fun `highlight then dismiss controls banner`() = runTest {
        val vm = SettingsViewModel(settingsRepo, recentsRepo, checker)
        advanceUntilIdle()
        assertFalse(vm.showPermissionBanner)
        vm.highlightPermissionIssue()
        assertTrue(vm.showPermissionBanner)
        vm.dismissPermissionBanner()
        assertFalse(vm.showPermissionBanner)
    }

    @Test
    fun `clearRecents empties recents store`() = runTest {
        val vm = SettingsViewModel(settingsRepo, recentsRepo, checker)
        advanceUntilIdle()
        recentsRepo.record(
            RecentEntry(
                id = "app:x",
                title = "X",
                subtitle = null,
                packageName = "x",
                kind = "app",
                timestamp = 1,
                payload = "x",
            ),
        )
        advanceUntilIdle()
        assertFalse(recentsRepo.recents.first().isEmpty())

        vm.clearRecents()
        advanceUntilIdle()
        assertTrue(recentsRepo.recents.first().isEmpty())
    }
}
