package com.profapps.quicklaunch.search

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {

    @Test
    fun `plain query yields no hint`() {
        assertEquals(CommandHint.None, CommandParser.parse("chrome"))
        assertEquals(CommandHint.None, CommandParser.parse("hello world"))
        assertEquals(CommandHint.None, CommandParser.parse(""))
        assertEquals(CommandHint.None, CommandParser.parse("a"))
    }

    @Test
    fun `open prefix routes to app search`() {
        val hint = CommandParser.parse("open chrome")
        assertEquals(CommandHint.Open("chrome"), hint)
    }

    @Test
    fun `search and web prefixes route to web`() {
        assertEquals(CommandHint.Web("cats"), CommandParser.parse("search cats"))
        assertEquals(CommandHint.Web("cats"), CommandParser.parse("web cats"))
    }

    @Test
    fun `calc prefix and equals sign route to calculator`() {
        assertEquals(CommandHint.Calc("10*5"), CommandParser.parse("calc 10*5"))
        assertEquals(CommandHint.Calc("2+2"), CommandParser.parse("=2+2"))
    }

    @Test
    fun `convert prefix routes to conversion`() {
        assertEquals(
            CommandHint.Convert("10 km to miles"),
            CommandParser.parse("convert 10 km to miles"),
        )
    }

    @Test
    fun `settings prefix routes to settings`() {
        assertEquals(CommandHint.Settings("wifi"), CommandParser.parse("settings wifi"))
    }

    @Test
    fun `file and files prefixes route to file search`() {
        assertEquals(CommandHint.Files("report"), CommandParser.parse("file report"))
        assertEquals(CommandHint.Files("taxes"), CommandParser.parse("files taxes"))
        assertEquals(CommandHint.Files("pdf taxes"), CommandParser.parse("FILE pdf taxes"))
    }

    @Test
    fun `prefix alone does not trigger`() {
        // "open" without a term must not produce a hint with empty payload.
        assertEquals(CommandHint.None, CommandParser.parse("open"))
        // Two-char query "o " trimmed is too short.
        assertEquals(CommandHint.None, CommandParser.parse("o "))
        // "file" alone is a plain query (no trailing space -> no hint).
        assertEquals(CommandHint.None, CommandParser.parse("file"))
    }

    @Test
    fun `case insensitive prefixes`() {
        assertEquals(CommandHint.Open("chrome"), CommandParser.parse("OPEN chrome"))
        assertEquals(CommandHint.Web("cats"), CommandParser.parse("Search cats"))
    }

    @Test
    fun `hint is always None for plain app-like words`() {
        assertNull((CommandParser.parse("gmail") as? CommandHint.Open))
        assertTrue(CommandParser.parse("gmail") is CommandHint.None)
    }
}
