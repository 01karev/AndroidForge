package com.profapps.quicklaunch.providers

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.search.ranking.FuzzyMatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Contact search. Requires the optional READ_CONTACTS permission; when it is
 * denied the provider silently returns nothing — the settings screen explains
 * why and offers the grant button. We never nag or re-prompt on our own.
 */
class ContactsProvider(private val context: Context) : SearchProvider {

    override val id = ProviderIds.CONTACTS
    override val displayName = "Contacts"

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    override suspend fun search(query: SearchQuery): List<SearchResult> {
        if (!hasPermission()) return emptyList()
        val term = query.raw.trim()
        if (term.length < 2 || term.length > 40) return emptyList()

        return withContext(Dispatchers.IO) {
            val rows = queryContacts(term) ?: return@withContext emptyList()
            val results = mutableListOf<SearchResult>()
            for (row in rows) {
                val match = FuzzyMatcher.match(term, row.name) ?: continue
                if (match.score < 0.4f) continue
                results.add(
                    SearchResult(
                        id = "contact:${row.contactId}:${row.number}",
                        title = row.name,
                        subtitle = row.number,
                        icon = ResultIcon.LetterIcon(
                            letter = row.name.firstOrNull()?.uppercase() ?: "?",
                            hue = ((row.name.hashCode().let { if (it < 0) it.inv() else it } % 360) / 360f),
                        ),
                        score = match.score * 0.92f,
                        category = ResultCategory.CONTACTS,
                        recordable = true,
                        recordPayload = "tel:" + row.number,
                        action = { dial(row) },
                    )
                )
            }
            results.sortedByDescending { it.score }.take(8)
        }
    }

    private data class ContactRow(val contactId: String, val name: String, val number: String)

    private fun queryContacts(term: String): List<ContactRow>? {
        return try {
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
            )
            // Only cheap prefix/word-start SQL filtering; precise ranking happens here.
            val selection =
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? OR " +
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("$term%", "% $term%")
            context.contentResolver.query(uri, projection, selection, args, null)?.use { cursor ->
                val rows = mutableListOf<ContactRow>()
                val idIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext() && rows.size < 40) {
                    val name = cursor.getString(nameIdx) ?: continue
                    val number = cursor.getString(numIdx) ?: continue
                    rows.add(ContactRow(cursor.getString(idIdx) ?: "", name, number))
                }
                rows
            } ?: emptyList()
        } catch (e: SecurityException) {
            null
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun dial(row: ContactRow): ActionResult {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(row.number)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            ActionResult.Dismiss
        } catch (e: Exception) {
            ActionResult.Stay
        }
    }
}
