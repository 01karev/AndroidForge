package com.profapps.quicklaunch.providers

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.search.CommandHint
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.util.UiBridge
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * New in v2.2.0: small, zero-permission quick facts, answered the same way
 * the calculator answers math — type a word, get a row, tap to copy.
 *
 *  - "battery"          -> current charge % and charging state
 *  - "time" / "date"    -> current time or date, tap to copy
 *
 * Neither needs a new permission: battery level comes from a public sticky
 * broadcast, and the clock is just the device clock.
 */
class QuickInfoProvider(private val context: Context) : SearchProvider {

    override val id = ProviderIds.QUICK_INFO
    override val displayName = "Quick info"

    override suspend fun search(query: SearchQuery): List<SearchResult> {
        if (query.hint != CommandHint.None) return emptyList()
        val term = query.raw.trim().lowercase()
        if (term.length > 20) return emptyList()

        return when {
            BATTERY_WORDS.contains(term) -> listOfNotNull(batteryResult())
            TIME_WORDS.contains(term) -> listOf(timeResult())
            DATE_WORDS.contains(term) -> listOf(dateResult())
            else -> emptyList()
        }
    }

    private fun batteryResult(): SearchResult? {
        val status = runCatching {
            val intent = context.registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ) ?: return@runCatching null
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level < 0 || scale <= 0) return@runCatching null
            val percent = (level * 100) / scale
            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            percent to plugged
        }.getOrNull() ?: return null

        val (percent, charging) = status
        val subtitle = context.getString(
            if (charging) R.string.battery_charging else R.string.battery_not_charging,
        )
        return SearchResult(
            id = "info:battery",
            title = "$percent%",
            subtitle = subtitle,
            icon = ResultIcon.ResourceIcon(R.drawable.ic_bolt),
            score = 0.95f,
            category = ResultCategory.ACTIONS,
            copyText = "$percent%",
            recordable = false,
            action = {
                UiBridge.copy(context, "$percent%")
                UiBridge.toast(context, context.getString(R.string.copied))
                ActionResult.Stay
            },
        )
    }

    private fun timeResult(): SearchResult {
        val text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        return infoResult(id = "info:time", title = text, subtitleRes = R.string.quick_info_time_subtitle)
    }

    private fun dateResult(): SearchResult {
        val text = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())
        return infoResult(id = "info:date", title = text, subtitleRes = R.string.quick_info_date_subtitle)
    }

    private fun infoResult(id: String, title: String, subtitleRes: Int): SearchResult =
        SearchResult(
            id = id,
            title = title,
            subtitle = context.getString(subtitleRes),
            icon = ResultIcon.ResourceIcon(R.drawable.ic_history),
            score = 0.95f,
            category = ResultCategory.ACTIONS,
            copyText = title,
            recordable = false,
            action = {
                UiBridge.copy(context, title)
                UiBridge.toast(context, context.getString(R.string.copied))
                ActionResult.Stay
            },
        )

    private companion object {
        val BATTERY_WORDS = setOf("battery", "charge", "battery level")
        val TIME_WORDS = setOf("time", "clock", "what time is it")
        val DATE_WORDS = setOf("date", "today", "what day is it")
    }
}
