package com.profapps.quicklaunch.providers

import android.content.Context
import android.content.Intent
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.AppEntry
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.data.RecentsRepository
import com.profapps.quicklaunch.data.SettingsRepository
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.search.CommandHint
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.search.ranking.FuzzyMatcher
import com.profapps.quicklaunch.util.UiBridge

/**
 * Installed app search backed by the cached [AppIndex]. Supports prefix,
 * word-start, substring and fuzzy matching, plus recency and pinned boosts.
 */
class AppsProvider(
    private val context: Context,
    private val appIndex: AppIndex,
    private val recents: RecentsRepository,
    private val settings: SettingsRepository,
) : SearchProvider {

    override val id = ProviderIds.APPS
    override val displayName = "Apps"

    override suspend fun search(query: SearchQuery): List<SearchResult> {
        val term = when (val hint = query.hint) {
            is CommandHint.Open -> hint.term
            else -> query.raw
        }
        if (term.isBlank() || term.length > 50) return emptyList()

        val apps = appIndex.getApps()
        if (apps.isEmpty()) return emptyList()

        val boosts = recents.rankingBoosts()
        val pinned = settings.settings.value.pinnedApps
        val openCommand = query.hint is CommandHint.Open

        data class Hit(val score: Float, val app: AppEntry)

        val hits = mutableListOf<Hit>()
        for (app in apps) {
            val match = FuzzyMatcher.match(
                query = term,
                target = app.label,
                usageBoost = boosts[app.packageName] ?: 0f,
                pinnedBoost = if (app.packageName in pinned) PINNED_BOOST else 0f,
            ) ?: continue
            if (match.score < MIN_SCORE) continue
            // "open chrome" makes a plausible app match decisive.
            val score = match.score + if (openCommand && match.score >= 0.5f) 0.1f else 0f
            hits.add(Hit(score.coerceAtMost(1f), app))
        }

        return hits
            .sortedByDescending { it.score }
            .take(12)
            .map { hit ->
                SearchResult(
                    id = hit.app.id,
                    title = hit.app.label,
                    subtitle = hit.app.packageName,
                    icon = ResultIcon.AppIcon(hit.app.component),
                    score = hit.score,
                    category = ResultCategory.APPS,
                    recordable = true,
                    recordPayload = hit.app.packageName,
                    action = { launch(hit.app) },
                )
            }
    }

    private suspend fun launch(app: AppEntry): ActionResult {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(app.packageName, app.component.className)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            ActionResult.Dismiss
        } catch (e: Exception) {
            UiBridge.toast(context, context.getString(R.string.app_launch_failed, app.label))
            ActionResult.Stay
        }
    }

    private companion object {
        const val MIN_SCORE = 0.3f
        const val PINNED_BOOST = 0.18f
    }
}
