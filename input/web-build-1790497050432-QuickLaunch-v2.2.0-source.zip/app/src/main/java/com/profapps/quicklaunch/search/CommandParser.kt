package com.profapps.quicklaunch.search

/**
 * Detects explicit command prefixes ("open chrome", "calc 10*5") and routes
 * them as hints. Explicit commands only ever *add* focus for one provider;
 * ordinary search behaviour for plain queries is untouched.
 */
object CommandParser {

    fun parse(raw: String): CommandHint {
        val q = raw.trim()
        if (q.length < 2) return CommandHint.None
        val lower = q.lowercase()
        return when {
            lower.startsWith("open ") -> CommandHint.Open(q.substring(5).trim())
            lower.startsWith("launch ") -> CommandHint.Open(q.substring(7).trim())
            lower.startsWith("search ") -> CommandHint.Web(q.substring(7).trim())
            lower.startsWith("web ") -> CommandHint.Web(q.substring(4).trim())
            lower.startsWith("calc ") -> CommandHint.Calc(q.substring(5).trim())
            lower.startsWith("=") -> CommandHint.Calc(q.substring(1).trim())
            lower.startsWith("convert ") -> CommandHint.Convert(q.substring(8).trim())
            lower.startsWith("settings ") -> CommandHint.Settings(q.substring(9).trim())
            lower.startsWith("files ") -> CommandHint.Files(q.substring(6).trim())
            lower.startsWith("file ") -> CommandHint.Files(q.substring(5).trim())
            else -> CommandHint.None
        }
    }
}
