package com.profapps.quicklaunch.triggers.assist

import android.service.voice.VoiceInteractionService

/**
 * Entry point for the Android assistant integration. When the user sets
 * Quick Launch as their "Digital assistant app" (Settings > Apps > Default
 * apps > Digital assistant), every assist gesture — long-press the power
 * button, swipe from the corner on gestures — opens the command palette.
 */
class QuickLaunchVoiceService : VoiceInteractionService() {

    override fun onReady() {
        super.onReady()
        // Nothing to warm up: the session opens the overlay on demand.
    }
}
