package com.profapps.quicklaunch.ui.overlay

import android.content.Context
import android.view.inputmethod.InputMethodManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.profapps.quicklaunch.R
import kotlinx.coroutines.delay
import com.profapps.quicklaunch.data.AppEntry
import com.profapps.quicklaunch.data.RecentEntry
import com.profapps.quicklaunch.search.SearchResult

/** Visual row model for the palette list. */
internal sealed interface PanelRow {
    data class Header(val marker: String) : PanelRow
    data class Result(val result: SearchResult, val index: Int) : PanelRow
    data class Recent(val entry: RecentEntry) : PanelRow
    data class Pinned(val app: AppEntry) : PanelRow
    data object ClipboardSuggestion : PanelRow
    data object SampleChips : PanelRow
}

internal const val MARKER_RECENT = "\u0001recent"
internal const val MARKER_PINNED = "\u0001pinned"
internal const val MARKER_TRY = "\u0001try"

/**
 * The floating command palette: a compact Surface near the top of the screen
 * over a subtly dimmed background. Shared by the overlay window and the
 * in-app "try it" mode so window glue stays thin.
 */
@Composable
fun OverlayPanel(
    controller: PaletteController,
    topInsetPx: Int,
    sideMarginPx: Int,
    opacity: Float,
    compact: Boolean,
    animationsEnabled: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    dimBackground: Boolean = true,
) {
    val query by controller.query.collectAsState()
    val results by controller.results.collectAsState()
    val selection by controller.selection.collectAsState()
    val searching by controller.searching.collectAsState()
    val visible by controller.panelVisible.collectAsState()
    val recents by controller.recentsList.collectAsState()
    val pinned by controller.pinnedApps.collectAsState()
    val clipboard by controller.clipboardText.collectAsState()

    val density = LocalDensity.current
    val topInset = with(density) { topInsetPx.toDp() }
    val sideMargin = with(density) { sideMarginPx.toDp() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(if (dimBackground) Color.Black.copy(alpha = 0.34f) else Color.Transparent)
            .pointerInput(onDismiss) {
                // Tap on the dimmed background dismisses the palette.
                detectTapGestures { onDismiss() }
            },
    ) {
        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = if (animationsEnabled) {
                fadeIn(tween(130)) +
                    slideInVertically(tween(150, easing = FastOutSlowInEasing)) { -it / 10 }
            } else {
                EnterTransition.None
            },
            exit = if (animationsEnabled) {
                fadeOut(tween(100)) +
                    slideOutVertically(tween(120, easing = FastOutSlowInEasing)) { -it / 14 }
            } else {
                ExitTransition.None
            },
        ) {
            Surface(
                modifier = Modifier
                    .padding(start = sideMargin, end = sideMargin, top = topInset + 10.dp)
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
                    // Consume taps on the panel body so they never hit the scrim.
                    .pointerInput(Unit) { detectTapGestures { } }
                    .onPreviewKeyEvent { event ->
                        handlePanelKey(event, controller, onDismiss)
                    },
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = opacity),
                tonalElevation = 6.dp,
                shadowElevation = 10.dp,
            ) {
                Column {
                    SearchFieldRow(controller, query, searching, onDismiss)
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                    )
                    ResultsArea(
                        controller = controller,
                        query = query,
                        results = results,
                        selection = selection,
                        recents = recents,
                        pinned = pinned,
                        clipboard = clipboard,
                        compact = compact,
                    )
                }
            }
        }
    }
}

/** Hardware-keyboard support: arrows/Tab move, Enter activates, Esc/Back close. */
private fun handlePanelKey(
    event: KeyEvent,
    controller: PaletteController,
    onDismiss: () -> Unit,
): Boolean {
    if (event.type != KeyEventType.KeyDown) return false
    return when {
        event.key == Key.Enter || event.key == Key.NumPadEnter -> {
            if (controller.results.value.isNotEmpty()) controller.activateSelected()
            true
        }
        event.key == Key.DirectionDown || (event.key == Key.Tab && !event.isShiftPressed) -> {
            controller.moveSelection(1)
            true
        }
        event.key == Key.DirectionUp || (event.key == Key.Tab && event.isShiftPressed) -> {
            controller.moveSelection(-1)
            true
        }
        event.key == Key.Escape || event.key == Key.Back -> {
            onDismiss()
            true
        }
        else -> false
    }
}

@Composable
private fun SearchFieldRow(
    controller: PaletteController,
    query: String,
    searching: Boolean,
    onDismiss: () -> Unit,
) {
    val focusRequester = remember { FocusRequester() }
    val view = LocalView.current
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(Unit) {
        delay(50)
        runCatching { focusRequester.requestFocus() }
        delay(120)
        // Best effort: some OEMs refuse the IME for service-owned windows.
        runCatching {
            val imm = view.context
                .getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Rounded.Search,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(
                        text = stringResource(R.string.search_placeholder),
                        style = LocalTextStyle.current.copy(fontSize = 17.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = controller::onQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester),
                    textStyle = LocalTextStyle.current.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 17.sp,
                    ),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { controller.activateSelected() }),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                )
            }
            IconButton(
                onClick = {
                    // Voice "assistant" trigger from inside the palette itself:
                    // speak instead of type. Handled by the zero-setup trampoline.
                    runCatching {
                        context.startActivity(
                            android.content.Intent(
                                context,
                                com.profapps.quicklaunch.triggers.VoiceSearchActivity::class.java,
                            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                    onDismiss()
                },
                modifier = Modifier.size(34.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Mic,
                    contentDescription = stringResource(R.string.voice_search_cd),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(
                onClick = { if (query.isEmpty()) onDismiss() else controller.onQueryChange("") },
                modifier = Modifier.size(34.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = stringResource(
                        if (query.isEmpty()) R.string.dismiss_palette else R.string.clear_query,
                    ),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (searching && query.isNotBlank()) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp)
                    .heightIn(max = 2.dp),
                trackColor = Color.Transparent,
            )
        }
    }
}

@Composable
private fun ResultsArea(
    controller: PaletteController,
    query: String,
    results: List<SearchResult>,
    selection: Int,
    recents: List<RecentEntry>,
    pinned: List<AppEntry>,
    clipboard: String?,
    compact: Boolean,
) {
    val rows = remember(query, results, recents, pinned, clipboard) {
        if (query.isBlank()) {
            buildEmptyStateRows(recents, pinned, clipboard)
        } else {
            buildResultRows(results)
        }
    }
    val listState = rememberLazyListState()

    // Keep the keyboard-selected row visible without fighting the user's scroll.
    LaunchedEffect(selection, rows) {
        if (selection <= 0) return@LaunchedEffect
        val index = rows.indexOfFirst { it is PanelRow.Result && it.index == selection }
        if (index < 0) return@LaunchedEffect
        val visibleNow = listState.layoutInfo.visibleItemsInfo.any { it.index == index }
        if (!visibleNow) {
            // Guard: the list can shrink between the check and the scroll call
            // (fresh results arriving mid-animation) — never crash for that.
            val safeIndex = index.coerceIn(0, (rows.size - 1).coerceAtLeast(0))
            runCatching { listState.animateScrollToItem(safeIndex) }
        }
    }

    BoxWithConstraints {
        val maxListHeight = minOf(maxHeight * 0.58f, if (compact) 500.dp else 420.dp)
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = maxListHeight)
                .padding(top = 4.dp, bottom = 6.dp),
        ) {
            itemsIndexed(rows, key = { index, row -> rowKey(row, index) }) { _, row ->
                PanelRowItem(
                    row = row,
                    controller = controller,
                    selection = selection,
                    compact = compact,
                )
            }
            if (rows.isEmpty() && query.isNotBlank()) {
                item(key = "empty") { NoResultsBlock() }
            }
        }
    }
}

/**
 * Fixed crash: results are sorted by score first and category only as a
 * tiebreaker, so the same category can legitimately appear more than once,
 * non-contiguously, in [buildResultRows] (e.g. Apps, Web, Apps again). That
 * produced two `PanelRow.Header` rows with the identical marker, and two
 * identical LazyColumn keys ("h:apps") crash the app with
 * "IllegalArgumentException: Key ... was already used". Headers are the only
 * row kind without a naturally unique identity, so their key folds in the
 * row's position; every other row already has a stable, globally unique id
 * and keeps that same key so re-ordering across keystrokes still animates
 * smoothly instead of resetting.
 */
private fun rowKey(row: PanelRow, index: Int): String = when (row) {
    is PanelRow.Header -> "h:${row.marker}:$index"
    is PanelRow.Result -> "r:${row.result.id}"
    is PanelRow.Recent -> "recent:${row.entry.id}"
    is PanelRow.Pinned -> "pin:${row.app.packageName}"
    PanelRow.ClipboardSuggestion -> "clipboard"
    PanelRow.SampleChips -> "chips"
}

internal fun buildEmptyStateRows(
    recents: List<RecentEntry>,
    pinned: List<AppEntry>,
    clipboard: String?,
): List<PanelRow> = buildList {
    if (!clipboard.isNullOrEmpty()) add(PanelRow.ClipboardSuggestion)
    if (recents.isNotEmpty()) {
        add(PanelRow.Header(MARKER_RECENT))
        recents.forEach { add(PanelRow.Recent(it)) }
    }
    if (pinned.isNotEmpty()) {
        add(PanelRow.Header(MARKER_PINNED))
        pinned.forEach { add(PanelRow.Pinned(it)) }
    }
    add(PanelRow.Header(MARKER_TRY))
    add(PanelRow.SampleChips)
}

internal fun buildResultRows(results: List<SearchResult>): List<PanelRow> {
    if (results.isEmpty()) return emptyList()
    val categories = results.map { it.category }.distinct()
    // Do not over-section a short list: headers only when there is real variety.
    val useHeaders = categories.size >= 2 && results.size >= 4
    if (!useHeaders) {
        return results.mapIndexed { index, result -> PanelRow.Result(result, index) }
    }
    return buildList {
        var last: com.profapps.quicklaunch.search.ResultCategory? = null
        results.forEachIndexed { index, result ->
            if (result.category != last) {
                add(PanelRow.Header(categoryMarker(result.category)))
                last = result.category
            }
            add(PanelRow.Result(result, index))
        }
    }
}

internal fun categoryMarker(category: com.profapps.quicklaunch.search.ResultCategory): String =
    when (category) {
        com.profapps.quicklaunch.search.ResultCategory.APPS -> "apps"
        com.profapps.quicklaunch.search.ResultCategory.ACTIONS -> "actions"
        com.profapps.quicklaunch.search.ResultCategory.CALCULATOR -> "calc"
        com.profapps.quicklaunch.search.ResultCategory.CONVERSIONS -> "conv"
        com.profapps.quicklaunch.search.ResultCategory.FILES -> "files"
        com.profapps.quicklaunch.search.ResultCategory.CONTACTS -> "contacts"
        com.profapps.quicklaunch.search.ResultCategory.WEB -> "web"
        com.profapps.quicklaunch.search.ResultCategory.SETTINGS -> "settings"
        com.profapps.quicklaunch.search.ResultCategory.CLIPBOARD -> "clipboard"
    }
