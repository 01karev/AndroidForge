package com.profapps.quicklaunch.triggers

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.profapps.quicklaunch.providers.AppIndex
import com.profapps.quicklaunch.util.IconLoader

/**
 * Publishes one dynamic launcher shortcut per pinned app, so long-pressing the
 * Quick Launch icon on the home screen offers direct one-tap launches. Pinned
 * apps in the palette and shortcuts on the launcher always stay in sync.
 */
object PinnedShortcuts {

    private const val ID_PREFIX = "pin:"
    private const val MAX_SHORTCUTS = 4

    suspend fun update(context: Context, pinnedPackages: Set<String>, appIndex: AppIndex) {
        if (Build.VERSION.SDK_INT < 25) return
        runCatching {
            val apps = appIndex.getApps()
                .filter { it.packageName in pinnedPackages }
                .take(MAX_SHORTCUTS)
            val shortcuts = apps.map { entry ->
                val intent = Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(entry.packageName, entry.component.className)
                    .setPackage(entry.packageName)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                ShortcutInfoCompat.Builder(context, ID_PREFIX + entry.packageName)
                    .setShortLabel(entry.label)
                    .setIntent(intent)
                    .setIcon(iconFor(context, entry))
                    .build()
            }
            ShortcutManagerCompat.setDynamicShortcuts(context, shortcuts)
        }
    }

    private fun iconFor(context: Context, entry: com.profapps.quicklaunch.data.AppEntry): IconCompat? {
        val bitmap = IconLoader.loadAppIcon(context, entry.component) ?: return null
        return IconCompat.createWithAdaptiveBitmap(bitmap)
    }
}
