package com.profapps.quicklaunch.triggers

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.profapps.quicklaunch.MainActivity
import com.profapps.quicklaunch.overlay.OverlayController

/**
 * Invisible trampoline used by the home-screen widget, the launcher shortcuts
 * and any other entry point to open the palette. Being an Activity makes the
 * foreground-service start legal from widget taps and gives a single place
 * for the fallback: when the overlay permission is missing, the in-app
 * palette is shown instead.
 *
 * Supported modes (via intent action):
 *  - [ACTION_VOICE_SEARCH]: hands over to [VoiceSearchActivity] (speech).
 *  - [ACTION_FILE_SEARCH]: opens the palette pre-filled with the file filter.
 *  - anything else: opens the palette normally.
 */
class PaletteLaunchActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when (intent?.action) {
            ACTION_VOICE_SEARCH -> {
                runCatching {
                    startActivity(
                        Intent(this, VoiceSearchActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                }
            }
            ACTION_FILE_SEARCH -> {
                val prefill = intent.getStringExtra(EXTRA_PREFILL) ?: "file "
                if (OverlayController.isPermissionGranted(this)) {
                    OverlayController.show(this, prefill)
                } else {
                    runCatching {
                        startActivity(
                            Intent(this, MainActivity::class.java)
                                .putExtra(MainActivity.EXTRA_OPEN_OVERLAY, true)
                                .putExtra(MainActivity.EXTRA_PREFILL_QUERY, prefill)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                }
            }
            else -> {
                if (OverlayController.isPermissionGranted(this)) {
                    OverlayController.show(this)
                } else {
                    runCatching {
                        startActivity(
                            Intent(this, MainActivity::class.java)
                                .putExtra(MainActivity.EXTRA_OPEN_OVERLAY, true)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                }
            }
        }
        finish()
    }

    companion object {
        const val ACTION_VOICE_SEARCH = "com.profapps.quicklaunch.action.VOICE_SEARCH"
        const val ACTION_FILE_SEARCH = "com.profapps.quicklaunch.action.FILE_SEARCH"
        const val EXTRA_PREFILL = "prefill"
    }
}
