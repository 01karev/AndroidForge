package com.profapps.quicklaunch.triggers

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.profapps.quicklaunch.R

/**
 * Home-screen widget: a compact bolt button that opens the command palette.
 * The tap routes through [PaletteLaunchActivity] so both the overlay case and
 * the missing-permission fallback behave exactly like every other trigger.
 */
class QuickLaunchWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
    ) {
        val views = buildViews(context)
        appWidgetIds.forEach { id -> appWidgetManager.updateAppWidget(id, views) }
    }

    companion object {
        fun buildViews(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_quick_launch)

            // Bolt: open the palette.
            val launch = PendingIntent.getActivity(
                context,
                REQUEST_CODE,
                Intent(context, PaletteLaunchActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            views.setOnClickPendingIntent(R.id.widget_root, launch)

            // Mic: zero-setup voice search (speech dialog -> palette).
            val voice = PendingIntent.getActivity(
                context,
                REQUEST_CODE_VOICE,
                Intent(context, VoiceSearchActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            views.setOnClickPendingIntent(R.id.widget_mic, voice)

            return views
        }

        /** Forces a refresh after upgrades (icons/labels). */
        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, QuickLaunchWidgetProvider::class.java),
            )
            if (ids.isNotEmpty()) {
                manager.updateAppWidget(ids, buildViews(context))
            }
        }

        private const val REQUEST_CODE = 2101
        private const val REQUEST_CODE_VOICE = 2102
    }
}
