package com.profapps.quicklaunch.ui.settings

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.data.ThemeMode
import com.profapps.quicklaunch.data.WebEngine
import com.profapps.quicklaunch.triggers.assist.AssistantRoleHelper
import com.profapps.quicklaunch.triggers.assist.findActivity

/**
 * The main app screen: a compact control center. Flat list design on purpose —
 * sections and rows, not a dashboard of cards.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onTestOverlay: () -> Unit,
) {
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Re-read permission state whenever the user comes back from system UI.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refresh()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val contactsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { viewModel.refresh() }

    val filesPermissionsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { viewModel.refresh() }

    // Ask for the media permissions the moment the screen appears, mirroring
    // how the notification permission is requested up front.
    androidx.compose.runtime.LaunchedEffect(Unit) {
        if (!viewModel.filesPermissionGranted) {
            filesPermissionsLauncher.launch(filesPermissions())
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.settings_title))
                        Text(
                            text = stringResource(R.string.settings_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
        ) {
            if (viewModel.showPermissionBanner && !viewModel.overlayPermissionGranted) {
                PermissionBanner(
                    onGrant = {
                        viewModel.dismissPermissionBanner()
                        openOverlaySettings(context)
                    },
                    onDismiss = { viewModel.dismissPermissionBanner() },
                )
            }

            SectionHeader(stringResource(R.string.section_quick_launch))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Bolt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp),
                )
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.overlay_permission),
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Text(
                        text = stringResource(
                            if (viewModel.overlayPermissionGranted) {
                                R.string.overlay_granted
                            } else {
                                R.string.overlay_missing
                            },
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (viewModel.overlayPermissionGranted) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.error
                        },
                    )
                }
                if (!viewModel.overlayPermissionGranted) {
                    OutlinedButton(onClick = { openOverlaySettings(context) }) {
                        Text(stringResource(R.string.grant_permission))
                    }
                }
            }
            Button(
                onClick = onTestOverlay,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
            ) {
                Icon(Icons.Rounded.Bolt, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.test_overlay))
            }
            Text(
                text = stringResource(R.string.try_in_app),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp),
            )

            SectionHeader(stringResource(R.string.section_triggers))
            SwitchRow(
                title = stringResource(R.string.trigger_notification),
                description = stringResource(R.string.trigger_notification_desc),
                checked = settings.notificationTriggerEnabled && viewModel.notificationPermissionGranted,
                enabled = viewModel.notificationPermissionGranted,
                onChecked = { viewModel.setNotificationTrigger(it) },
            )
            if (!viewModel.notificationPermissionGranted) {
                Text(
                    text = stringResource(R.string.notification_permission_needed),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
            SwitchRow(
                title = stringResource(R.string.trigger_bubble),
                description = stringResource(R.string.trigger_bubble_desc),
                checked = settings.bubbleTriggerEnabled,
                enabled = viewModel.overlayPermissionGranted,
                onChecked = { viewModel.setBubbleTrigger(it) },
            )
            if (!viewModel.overlayPermissionGranted) {
                Text(
                    text = stringResource(R.string.overlay_missing),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
            InfoRow(
                title = stringResource(R.string.trigger_tile),
                description = stringResource(R.string.trigger_tile_desc),
            )
            InfoRow(
                title = stringResource(R.string.trigger_widget),
                description = stringResource(R.string.trigger_widget_desc),
            )
            InfoRow(
                title = stringResource(R.string.trigger_shortcut),
                description = stringResource(R.string.trigger_shortcut_desc),
            )
            InfoRow(
                title = stringResource(R.string.trigger_voice),
                description = stringResource(R.string.trigger_voice_desc),
                actionLabel = stringResource(R.string.try_it),
                onAction = {
                    runCatching {
                        context.startActivity(
                            Intent(context, com.profapps.quicklaunch.triggers.VoiceSearchActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                },
            )
            InfoRow(
                title = stringResource(R.string.trigger_assistant),
                description = stringResource(R.string.trigger_assistant_desc),
                actionLabel = stringResource(
                    if (viewModel.assistantRoleHeld) {
                        R.string.assistant_default_done
                    } else {
                        R.string.trigger_assistant_set
                    },
                ),
                onAction = {
                    // One-tap: the system dialog "Set Quick Launch as your
                    // assistant?" — no hunting through Settings lists.
                    //
                    // Fixed: this used to bail out completely with a bare
                    // `context as? Activity ?: return` whenever the Compose
                    // context wasn't literally an Activity instance (it can
                    // be wrapped), silently doing nothing and never falling
                    // back to the settings page. findActivity() walks the
                    // wrapper chain, and the fallback now always fires when
                    // no Activity can be found.
                    val activity = context.findActivity()
                    val started = activity != null &&
                        AssistantRoleHelper.requestAssistantRole(activity)
                    if (!started) AssistantRoleHelper.openAssistantSettings(context)
                },
            )
            InfoRow(
                title = stringResource(R.string.trigger_share),
                description = stringResource(R.string.trigger_share_desc),
            )

            SectionHeader(stringResource(R.string.section_appearance))
            Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
                Text(
                    text = stringResource(R.string.theme),
                    style = MaterialTheme.typography.bodyLarge,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeChip(
                        label = stringResource(R.string.theme_system),
                        selected = settings.themeMode == ThemeMode.SYSTEM,
                    ) { viewModel.setThemeMode(ThemeMode.SYSTEM) }
                    ThemeChip(
                        label = stringResource(R.string.theme_light),
                        selected = settings.themeMode == ThemeMode.LIGHT,
                    ) { viewModel.setThemeMode(ThemeMode.LIGHT) }
                    ThemeChip(
                        label = stringResource(R.string.theme_dark),
                        selected = settings.themeMode == ThemeMode.DARK,
                    ) { viewModel.setThemeMode(ThemeMode.DARK) }
                }
                Spacer(Modifier.size(8.dp))
                Text(
                    text = stringResource(
                        R.string.panel_opacity_desc,
                        (settings.panelOpacity * 100).toInt(),
                    ),
                    style = MaterialTheme.typography.bodyLarge,
                )
                Slider(
                    value = settings.panelOpacity,
                    onValueChange = { viewModel.setPanelOpacity(it) },
                    valueRange = 0.55f..1f,
                )
            }
            SwitchRow(
                title = stringResource(R.string.compact_mode),
                description = stringResource(R.string.compact_mode_desc),
                checked = settings.compactMode,
                onChecked = { viewModel.setCompactMode(it) },
            )
            SwitchRow(
                title = stringResource(R.string.animations),
                description = stringResource(R.string.animations_desc),
                checked = settings.animationsEnabled,
                onChecked = { viewModel.setAnimationsEnabled(it) },
            )

            SectionHeader(stringResource(R.string.section_providers))
            SettingsViewModel.PROVIDERS.forEach { provider ->
                if (provider.id == ProviderIds.FILES) {
                    SwitchRow(
                        title = stringResource(provider.nameRes),
                        description = stringResource(provider.descriptionRes),
                        checked = settings.isProviderEnabled(provider.id) && viewModel.filesPermissionGranted,
                        enabled = viewModel.filesPermissionGranted,
                        onChecked = { viewModel.setProviderEnabled(provider.id, it) },
                    )
                    if (!viewModel.filesPermissionGranted) {
                        Text(
                            text = stringResource(R.string.files_permission_needed),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(horizontal = 20.dp),
                        )
                    }
                } else {
                    SwitchRow(
                        title = stringResource(provider.nameRes),
                        description = stringResource(provider.descriptionRes),
                        checked = settings.isProviderEnabled(provider.id),
                        onChecked = { viewModel.setProviderEnabled(provider.id, it) },
                    )
                }
            }

            SectionHeader(stringResource(R.string.web_engine))
            Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WebEngine.entries.forEach { engine ->
                        FilterChip(
                            selected = settings.webEngine == engine,
                            onClick = { viewModel.setWebEngine(engine) },
                            label = { Text(engine.label) },
                        )
                    }
                }
            }

            SectionHeader(stringResource(R.string.section_privacy))
            Text(
                text = stringResource(R.string.privacy_body),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            ListItem(
                colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
                headlineContent = { Text(stringResource(R.string.contacts_permission)) },
                supportingContent = { Text(stringResource(R.string.privacy_contacts)) },
                trailingContent = {
                    if (viewModel.contactsPermissionGranted) {
                        Icon(
                            Icons.Rounded.Check,
                            contentDescription = stringResource(R.string.contacts_allowed),
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    } else {
                        TextButton(
                            onClick = {
                                contactsLauncher.launch(Manifest.permission.READ_CONTACTS)
                            },
                        ) {
                            Text(stringResource(R.string.grant_permission))
                        }
                    }
                },
            )
            ListItem(
                colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
                headlineContent = { Text(stringResource(R.string.section_recent)) },
                supportingContent = { Text(stringResource(R.string.privacy_recents)) },
                trailingContent = {
                    TextButton(onClick = { viewModel.clearRecents() }) {
                        Text(stringResource(R.string.clear_recents))
                    }
                },
            )
            Text(
                text = stringResource(R.string.privacy_clipboard),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            Text(
                text = stringResource(R.string.privacy_files),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            Spacer(Modifier.size(24.dp))
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Column {
        Spacer(Modifier.size(18.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        HorizontalDivider(
            modifier = Modifier.padding(top = 6.dp),
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
        )
    }
}

@Composable
private fun SwitchRow(
    title: String,
    description: String,
    checked: Boolean,
    onChecked: (Boolean) -> Unit,
    enabled: Boolean = true,
) {
    ListItem(
        colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
        headlineContent = { Text(title) },
        supportingContent = { Text(description) },
        trailingContent = {
            Switch(checked = checked, onCheckedChange = onChecked, enabled = enabled)
        },
    )
}

@Composable
private fun InfoRow(
    title: String,
    description: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    ListItem(
        colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
        headlineContent = { Text(title) },
        supportingContent = { Text(description) },
        trailingContent = {
            if (actionLabel != null && onAction != null) {
                OutlinedButton(onClick = onAction) {
                    Text(actionLabel)
                }
            }
        },
    )
}

/** Media permissions for the file search provider, per Android version. */
private fun filesPermissions(): Array<String> =
    if (android.os.Build.VERSION.SDK_INT >= 33) {
        arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO,
        )
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

@Composable
private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
private fun PermissionBanner(onGrant: () -> Unit, onDismiss: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
        ),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Rounded.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.overlay_permission),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
            Spacer(Modifier.size(8.dp))
            Text(
                text = stringResource(R.string.overlay_missing_banner),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Spacer(Modifier.size(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onGrant) {
                    Text(stringResource(R.string.open_settings_route))
                }
                TextButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.clear_query))
                }
            }
        }
    }
}

private fun openOverlaySettings(context: android.content.Context) {
    val intent = Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:${context.packageName}"),
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
        .onFailure {
            // Extremely rare: fall back to the general app details page.
            runCatching {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.parse("package:${context.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        }
}
