package com.profapps.quicklaunch.ui.overlay

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.profapps.quicklaunch.QuickLaunchApp
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import com.profapps.quicklaunch.ui.overlay.OverlayPanel
import com.profapps.quicklaunch.ui.overlay.PaletteController

/**
 * The palette rendered inside the app activity. Two uses:
 *  1. the in-app fallback when the overlay permission is missing, and
 *  2. an instant "test" surface that behaves exactly like the floating one.
 * Also hosts shared text ("Share to Quick Launch") via [initialQuery].
 */
@Composable
fun InAppPaletteScreen(onClose: () -> Unit, initialQuery: String? = null) {
    val context = LocalContext.current
    val app = context.applicationContext as QuickLaunchApp

    // A custom scope with a crash guard: an exception escaping a palette
    // coroutine (clipboard/DataStore/hardware quirks) would otherwise tear
    // down the whole activity. Here it is contained and logged instead.
    val scope = remember {
        CoroutineScope(
            SupervisorJob() + Dispatchers.Main.immediate +
                CoroutineExceptionHandler { _, t ->
                    android.util.Log.e("QuickLaunch", "Palette scope failure", t)
                },
        )
    }
    DisposableEffect(Unit) {
        onDispose { scope.cancel() }
    }

    val controller = remember {
        PaletteController(
            context = context,
            engine = app.container.searchEngine,
            recents = app.container.recentsRepository,
            settings = app.container.settingsRepository,
            appIndex = app.container.appIndex,
            scope = scope,
            onDismiss = onClose,
        )
    }

    LaunchedEffect(Unit) {
        controller.onPaletteShown()
        initialQuery?.takeIf { it.isNotBlank() }?.let { controller.onQueryChange(it) }
    }
    BackHandler(onBack = onClose)

    val density = LocalDensity.current
    val topInsetPx = WindowInsets.statusBars.getTop(density)
    val sideMarginPx = with(density) { 12.dp.roundToPx() }
    val snapshot = app.container.settingsRepository.settings.value

    OverlayPanel(
        controller = controller,
        topInsetPx = topInsetPx,
        sideMarginPx = sideMarginPx,
        opacity = snapshot.panelOpacity,
        compact = snapshot.compactMode,
        animationsEnabled = snapshot.animationsEnabled,
        onDismiss = onClose,
        dimBackground = true,
    )
}
