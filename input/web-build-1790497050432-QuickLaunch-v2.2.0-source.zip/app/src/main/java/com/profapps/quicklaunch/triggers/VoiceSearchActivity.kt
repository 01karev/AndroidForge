package com.profapps.quicklaunch.triggers

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import com.profapps.quicklaunch.MainActivity
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.overlay.OverlayController
import com.profapps.quicklaunch.util.UiBridge

/**
 * The zero-setup "assistant" voice trigger.
 *
 * The assist-gesture integration only works after the user assigns Quick
 * Launch as the system's default digital assistant, which is why the old
 * assistant shortcut appeared "dead" for most people. This activity instead
 * opens the standard platform speech dialog — available on every Android
 * device with the Google app — and pushes the recognized text straight into
 * the command palette (floating overlay when permitted, in-app otherwise).
 *
 * It is deliberately a translucent trampoline: it shows no UI of its own,
 * finishes as soon as the speech dialog resolves, and is safe to target from
 * launcher shortcuts and home-screen widgets.
 */
class VoiceSearchActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                )
                putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_prompt))
            }
            startActivityForResult(intent, REQUEST_SPEECH)
        } catch (e: ActivityNotFoundException) {
            UiBridge.toast(this, getString(R.string.voice_unavailable))
            openPalette(null)
        } catch (e: Exception) {
            // Some OEM builds throw odd runtime errors here; still land
            // somewhere useful instead of crashing.
            openPalette(null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_SPEECH) {
            finish()
            return
        }
        val transcript = if (resultCode == RESULT_OK) {
            data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
        } else {
            null
        }
        openPalette(transcript)
    }

    private fun openPalette(query: String?) {
        runCatching {
            when {
                // A spoken query with overlay permission: palette + search.
                query != null && OverlayController.isPermissionGranted(this) ->
                    OverlayController.show(this, query)

                // A spoken query without the overlay: in-app palette, prefilled.
                query != null ->
                    startActivity(
                        Intent(this, MainActivity::class.java)
                            .putExtra(MainActivity.EXTRA_PREFILL_QUERY, query)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )

                // Nothing recognized (cancel / no engine): just open the palette.
                OverlayController.isPermissionGranted(this) ->
                    OverlayController.show(this)

                else ->
                    startActivity(
                        Intent(this, MainActivity::class.java)
                            .putExtra(MainActivity.EXTRA_OPEN_OVERLAY, true)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
            }
        }
        finish()
    }

    private companion object {
        const val REQUEST_SPEECH = 7014
    }
}
