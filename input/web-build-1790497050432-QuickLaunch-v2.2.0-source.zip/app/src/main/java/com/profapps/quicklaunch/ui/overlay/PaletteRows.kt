package com.profapps.quicklaunch.ui.overlay

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.AppEntry
import com.profapps.quicklaunch.data.RecentEntry
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.util.IconLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Opens a row for tap. */
private fun Modifier.clickableRow(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)

/** Maps header markers to localized labels. */
@Composable
private fun String.label(): String = when (this) {
    MARKER_RECENT -> stringResource(R.string.section_recent)
    MARKER_PINNED -> stringResource(R.string.section_pinned)
    MARKER_TRY -> stringResource(R.string.section_try)
    "apps" -> stringResource(R.string.category_apps)
    "actions" -> stringResource(R.string.category_actions)
    "calc" -> stringResource(R.string.category_calculator)
    "conv" -> stringResource(R.string.category_conversions)
    "files" -> stringResource(R.string.category_files)
    "contacts" -> stringResource(R.string.category_contacts)
    "web" -> stringResource(R.string.category_web)
    "settings" -> stringResource(R.string.category_settings)
    "clipboard" -> stringResource(R.string.category_clipboard)
    else -> this
}

/** Dispatches a visual row of the palette list. */
@Composable
internal fun PanelRowItem(
    row: PanelRow,
    controller: PaletteController,
    selection: Int,
    compact: Boolean,
) {
    when (row) {
        is PanelRow.Header -> HeaderRow(row.marker)
        is PanelRow.Result -> ResultRow(
            result = row.result,
            selected = row.index == selection,
            compact = compact,
            onActivate = { controller.activate(row.result) },
            onCopy = { row.result.copyText?.let { controller.copyToClipboard(it) } },
            onPinToggle = { controller.togglePinnedFromResult(row.result) },
        )
        is PanelRow.Recent -> RecentRow(row.entry, controller)
        is PanelRow.Pinned -> PinnedRow(row.app, controller)
        PanelRow.ClipboardSuggestion -> ClipboardRow(controller)
        PanelRow.SampleChips -> SampleChipsRow(controller)
    }
}

@Composable
internal fun HeaderRow(marker: String) {
    Text(
        text = marker.label(),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 4.dp),
    )
}

@Composable
internal fun NoResultsBlock() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 22.dp),
    ) {
        Text(
            text = stringResource(R.string.no_results),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.size(4.dp))
        Text(
            text = stringResource(R.string.no_results_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ResultRow(
    result: SearchResult,
    selected: Boolean,
    compact: Boolean,
    onActivate: () -> Unit,
    onCopy: () -> Unit,
    onPinToggle: () -> Unit,
) {
    val background by animateColorAsState(
        targetValue = if (selected) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
        } else {
            Color.Transparent
        },
        animationSpec = tween(90),
        label = "selectionBackground",
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .background(background, RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onActivate,
                onLongClick = if (result.category == ResultCategory.APPS) onPinToggle else null,
            )
            .padding(
                horizontal = 10.dp,
                vertical = if (compact) 6.dp else 9.dp,
            ),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ResultIconView(
            icon = result.icon,
            size = if (result.category == ResultCategory.APPS) 30.dp else 22.dp,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = result.title,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = if (compact) 14.sp else 15.sp,
                ),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (!compact && !result.subtitle.isNullOrEmpty()) {
                Text(
                    text = result.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (!result.copyText.isNullOrEmpty()) {
            IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                Icon(
                    imageVector = Icons.Rounded.ContentCopy,
                    contentDescription = stringResource(R.string.copy_result),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(17.dp),
                )
            }
        }
    }
}

@Composable
private fun RecentRow(entry: RecentEntry, controller: PaletteController) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .background(Color.Transparent, RoundedCornerShape(12.dp))
            .clickableRow { controller.replay(entry) }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RecentIconView(entry)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = entry.title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (!entry.subtitle.isNullOrEmpty()) {
                Text(
                    text = entry.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun RecentIconView(entry: RecentEntry) {
    if (entry.kind == RecentEntry.KIND_APP && entry.payload.isNotEmpty()) {
        val context = androidx.compose.ui.platform.LocalContext.current
        val bitmap by produceState<ImageBitmap?>(null, entry.payload) {
            value = withContext(Dispatchers.IO) {
                val component = runCatching {
                    context.packageManager
                        .getLaunchIntentForPackage(entry.payload)
                        ?.component
                }.getOrNull()
                component?.let { IconLoader.loadAppIcon(context, it) }?.asImageBitmap()
            }
        }
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!,
                contentDescription = stringResource(R.string.cd_app_icon),
                modifier = Modifier.size(26.dp),
            )
            return
        }
    }
    IconView(
        resId = when (entry.kind) {
            RecentEntry.KIND_APP -> com.profapps.quicklaunch.R.drawable.ic_open
            RecentEntry.KIND_WEB -> com.profapps.quicklaunch.R.drawable.ic_web
            RecentEntry.KIND_SETTINGS -> com.profapps.quicklaunch.R.drawable.ic_bolt
            RecentEntry.KIND_CONTACT -> com.profapps.quicklaunch.R.drawable.ic_person
            RecentEntry.KIND_FILE -> com.profapps.quicklaunch.R.drawable.ic_file
            else -> com.profapps.quicklaunch.R.drawable.ic_history
        },
        size = 22.dp,
    )
}

@Composable
private fun PinnedRow(app: AppEntry, controller: PaletteController) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, app.packageName) {
        value = withContext(Dispatchers.IO) {
            IconLoader.loadAppIcon(context, app.component)?.asImageBitmap()
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .clickableRow { controller.launchPinnedApp(app) }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!,
                contentDescription = stringResource(R.string.cd_app_icon),
                modifier = Modifier.size(26.dp),
            )
        } else {
            IconView(resId = com.profapps.quicklaunch.R.drawable.ic_open, size = 22.dp)
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = app.label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun ClipboardRow(controller: PaletteController) {
    val clip by controller.clipboardText.collectAsState()
    val preview = clip?.take(48) ?: return
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .clickableRow { controller.searchClipboard() }
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconView(resId = com.profapps.quicklaunch.R.drawable.ic_clipboard, size = 22.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.paste_and_search),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = "“$preview”",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SampleChipsRow(controller: PaletteController) {
    val samples = remember {
        // "ask why is the sky blue" used to route to the Ask AI provider,
        // which was removed in v2.1.0 — the chip was left behind and just
        // fell through to a plain web search with no indication why. Swapped
        // for a sample of the new quick-actions provider instead.
        listOf("calc 25*4", "10 km to mi", "battery", "settings wifi", "file photo", "search android")
    }
    FlowRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
    ) {
        samples.forEach { sample ->
            FilterChip(
                selected = false,
                onClick = { controller.onQueryChange(sample) },
                label = { Text(sample) },
            )
        }
    }
}

/** Tinted vector icon used for actions and non-app results. */
@Composable
internal fun IconView(resId: Int, size: Dp) {
    Image(
        painter = painterResource(resId),
        contentDescription = null,
        colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onSurfaceVariant),
        modifier = Modifier.size(size),
    )
}

/** Resolves any [ResultIcon] to a rendered icon. */
@Composable
internal fun ResultIconView(icon: ResultIcon?, size: Dp) {
    when (icon) {
        is ResultIcon.AppIcon -> {
            val context = androidx.compose.ui.platform.LocalContext.current
            val bitmap by produceState<ImageBitmap?>(null, icon.component) {
                value = withContext(Dispatchers.IO) {
                    IconLoader.loadAppIcon(context, icon.component)?.asImageBitmap()
                }
            }
            if (bitmap != null) {
                Image(
                    bitmap = bitmap!!,
                    contentDescription = stringResource(R.string.cd_app_icon),
                    modifier = Modifier.size(size),
                )
            } else {
                Box(
                    Modifier
                        .size(size)
                        .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
                )
            }
        }
        is ResultIcon.LetterIcon -> {
            val hue = icon.hue.coerceIn(0f, 1f)
            val color = Color.hsv(hue * 360f, 0.55f, 0.62f)
            Box(
                modifier = Modifier
                    .size(size)
                    .background(color, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = icon.letter,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                )
            }
        }
        is ResultIcon.ResourceIcon -> IconView(icon.resId, size)
        null -> Spacer(Modifier.size(size))
    }
}
