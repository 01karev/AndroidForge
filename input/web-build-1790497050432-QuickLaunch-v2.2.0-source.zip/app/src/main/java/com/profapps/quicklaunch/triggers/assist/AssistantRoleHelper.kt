package com.profapps.quicklaunch.triggers.assist

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.app.role.RoleManager

/**
 * Unwraps a [Context] to find the nearest [Activity], walking the
 * [ContextWrapper] chain. Compose's `LocalContext.current` is not always the
 * raw Activity — some hosts and theming layers wrap it — so a direct
 * `context as? Activity` cast can silently return null even while running
 * inside an Activity. That silent null previously made the "Set as
 * assistant" button do nothing at all in some cases, since the code path
 * that read `context as? Activity ?: return` short-circuited before ever
 * trying the settings-page fallback.
 */
fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return ctx as? Activity
}

/**
 * Helpers around the Android 10+ assistant ROLE so the user can set Quick
 * Launch as the digital assistant with ONE tap, straight from the app —
 * no hunting through Settings lists.
 */
object AssistantRoleHelper {

    private const val ROLE_REQUEST_CODE = 2001

    /** True when this build of Android supports the assistant role request. */
    fun isRoleRequestSupported(): Boolean = Build.VERSION.SDK_INT >= 29

    /** True when Quick Launch is currently the default digital assistant. */
    fun isDefaultAssistant(context: Context): Boolean = try {
        Build.VERSION.SDK_INT >= 29 &&
            (context.getSystemService(RoleManager::class.java)
                ?.isRoleHeld(RoleManager.ROLE_ASSISTANT) == true)
    } catch (t: Throwable) {
        false
    }

    /**
     * Launches the system "Set Quick Launch as your assistant?" dialog.
     * Returns true when the dialog was started; false when the device does
     * not support it (the caller should fall back to [openAssistantSettings]).
     */
    fun requestAssistantRole(activity: Activity): Boolean = try {
        if (Build.VERSION.SDK_INT >= 29) {
            val roleManager = activity.getSystemService(RoleManager::class.java)
            if (roleManager != null &&
                roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)
            ) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)
                activity.startActivityForResult(intent, ROLE_REQUEST_CODE)
                true
            } else {
                false
            }
        } else {
            false
        }
    } catch (t: Throwable) {
        false
    }

    /** Deep link into the digital assistant settings page (best effort). */
    fun openAssistantSettings(context: Context): Boolean {
        val deep = runCatching {
            context.startActivity(
                Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }.isSuccess
        if (deep) return true
        return runCatching {
            context.startActivity(
                Intent(Settings.ACTION_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }.isSuccess
    }

    /** Unused helper kept for API parity with older request patterns. */
    fun roleRequestExtras(): Bundle = Bundle.EMPTY
}
