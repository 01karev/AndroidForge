package com.profapps.quicklaunch

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import com.profapps.quicklaunch.overlay.OverlayController
import com.profapps.quicklaunch.triggers.BootCompletedReceiver
import com.profapps.quicklaunch.triggers.FloatingBubbleService
import com.profapps.quicklaunch.triggers.NotificationTrigger
import com.profapps.quicklaunch.triggers.PinnedShortcuts
import com.profapps.quicklaunch.triggers.QuickLaunchWidgetProvider
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class QuickLaunchApp : Application() {

    // Without a handler here, any uncaught exception in a background collector
    // (DataStore hiccup, OEM broadcast quirk...) kills the whole process — one
    // of the main classes of "random crashes". With it we log and survive.
    private val crashGuard = CoroutineExceptionHandler { _, t ->
        android.util.Log.e("QuickLaunch", "Background task failed", t)
    }

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default + crashGuard)

    lateinit var container: AppContainer
        private set

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_PACKAGE_ADDED,
                Intent.ACTION_PACKAGE_REPLACED,
                Intent.ACTION_PACKAGE_REMOVED,
                -> container.appIndex.invalidate()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this, appScope)

        NotificationTrigger.ensureChannels(this)

        appScope.launch {
            runCatching {
                container.settingsRepository.settings.collect { settings ->
                    NotificationTrigger.updatePersistentNotification(
                        this@QuickLaunchApp,
                        settings.notificationTriggerEnabled,
                    )
                }
            }
        }

        // Start/stop the floating bubble whenever the trigger is toggled, and
        // mirror the flag for BootCompletedReceiver (synchronous read there).
        appScope.launch {
            runCatching {
                container.settingsRepository.settings
                    .map { it.bubbleTriggerEnabled }
                    .distinctUntilChanged()
                    .collect { enabled ->
                        getSharedPreferences(BootCompletedReceiver.PREFS_NAME, MODE_PRIVATE)
                            .edit()
                            .putBoolean(BootCompletedReceiver.KEY_BUBBLE_ENABLED, enabled)
                            .apply()
                        if (enabled && OverlayController.isPermissionGranted(this@QuickLaunchApp)) {
                            FloatingBubbleService.start(this@QuickLaunchApp)
                        } else {
                            FloatingBubbleService.stop(this@QuickLaunchApp)
                        }
                    }
            }
        }

        // Keep launcher shortcuts in sync with the user's pinned apps.
        appScope.launch {
            runCatching {
                container.settingsRepository.settings
                    .map { it.pinnedApps }
                    .distinctUntilChanged()
                    .collect { pinned ->
                        if (pinned.isNotEmpty()) {
                            PinnedShortcuts.update(
                                this@QuickLaunchApp,
                                pinned,
                                container.appIndex,
                            )
                        }
                    }
            }
        }

        // Newly added widgets pick up the latest icon/tinting.
        appScope.launch {
            runCatching { QuickLaunchWidgetProvider.refreshAll(this@QuickLaunchApp) }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }
}
