package com.profapps.quicklaunch.providers

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.providers.files.FileTypes
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.search.CommandHint
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.search.ranking.FuzzyMatcher
import com.profapps.quicklaunch.util.UiBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * On-device file search over MediaStore. Finds documents, images, videos,
 * audio, archives and APKs by file name and opens them with an ACTION_VIEW
 * intent — no file contents are ever read or uploaded.
 *
 * Usage:
 *  - "file report" / "files invoice"        -> name search across all files
 *  - "file pdf taxes" / "file photo beach"  -> first token acts as a filter
 *  - plain queries (3+ chars)               -> low-priority file matches
 */
class FileSearchProvider(private val context: Context) : SearchProvider {

    override val id = ProviderIds.FILES
    override val displayName = "Files"

    /** One matched row from MediaStore. */
    private data class FoundFile(
        val uri: Uri,
        val name: String,
        val mime: String?,
        val size: Long,
        val folder: String?,
    )

    override suspend fun search(query: SearchQuery): List<SearchResult> =
        withContext(Dispatchers.IO) {
            val explicit = query.hint is CommandHint.Files
            val rawTerm = when (val hint = query.hint) {
                is CommandHint.Files -> hint.term
                is CommandHint.None -> query.raw
                else -> return@withContext emptyList()
            }
            // Plain queries: only start matching files from 3 chars to keep
            // the palette fast and avoid noise for two-letter taps.
            if (rawTerm.isBlank() || (!explicit && rawTerm.trim().length < MIN_PLAIN_QUERY)) {
                return@withContext emptyList()
            }

            val (term, filter) = FileTypes.parseFilter(rawTerm)
            if (term.isEmpty() && filter != null) {
                // "file photo" with no name: still useful — list recent photos.
                return@withContext mapFiles(recentOf(filter), "", filter, explicit)
            }
            if (term.length < 2) return@withContext emptyList()

            val files = queryFiles(term, filter)
            mapFiles(files, term, filter, explicit)
        }

    private fun mapFiles(
        files: List<FoundFile>,
        term: String,
        filter: FileTypes.Category?,
        explicit: Boolean,
    ): List<SearchResult> {
        val scored = files.mapNotNull { file ->
            val match = if (term.isEmpty()) {
                FuzzyMatcher.Match(0.5f, FuzzyMatcher.MatchKind.SUBSTRING)
            } else {
                FuzzyMatcher.match(term, FileTypes.stripExtension(file.name))
                    ?: FuzzyMatcher.match(term, file.name)
            }
            match ?: return@mapNotNull null
            val bonus = when {
                explicit -> 0.18f
                filter != null -> 0.10f
                else -> 0f
            }
            file to (match.score * (if (explicit) 1f else 0.92f) + bonus)
        }
            .sortedWith(compareByDescending<Pair<FoundFile, Float>> { it.second }.thenBy { it.first.name })
            .take(MAX_RESULTS)

        return scored.map { (file, score) ->
            val category = FileTypes.categoryFor(file.name, file.mime)
            SearchResult(
                id = "file:${file.uri}",
                title = file.name,
                subtitle = subtitleFor(file, category),
                icon = ResultIcon.ResourceIcon(iconFor(category)),
                score = score.coerceAtMost(1f),
                category = ResultCategory.FILES,
                copyText = file.uri.toString(),
                recordable = true,
                recordPayload = file.uri.toString(),
                action = { openFile(file) },
            )
        }
    }

    private fun subtitleFor(file: FoundFile, category: FileTypes.Category): String {
        val size = FileTypes.formatSize(file.size)
        val folder = file.folder
            ?.trimEnd('/')
            ?.substringAfterLast('/')
            ?.takeIf { it.isNotBlank() }
        return listOfNotNull(folder, size).joinToString(" • ")
            .ifEmpty { context.getString(categoryLabel(category)) }
    }

    private fun categoryLabel(category: FileTypes.Category): Int = when (category) {
        FileTypes.Category.DOCS -> R.string.file_kind_docs
        FileTypes.Category.IMAGES -> R.string.file_kind_images
        FileTypes.Category.VIDEOS -> R.string.file_kind_video
        FileTypes.Category.AUDIO -> R.string.file_kind_audio
        FileTypes.Category.ARCHIVES -> R.string.file_kind_archive
        FileTypes.Category.APK -> R.string.file_kind_apk
        FileTypes.Category.OTHER -> R.string.file_kind_other
    }

    private fun iconFor(category: FileTypes.Category): Int = when (category) {
        FileTypes.Category.IMAGES -> R.drawable.ic_image
        FileTypes.Category.VIDEOS -> R.drawable.ic_video
        FileTypes.Category.AUDIO -> R.drawable.ic_audio
        FileTypes.Category.APK -> R.drawable.ic_apk
        else -> R.drawable.ic_file
    }

    private suspend fun openFile(file: FoundFile): ActionResult {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(file.uri, FileTypes.mimeFor(file.name, file.mime))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            ActionResult.Dismiss
        } catch (e: Exception) {
            UiBridge.toast(context, context.getString(R.string.file_open_failed))
            ActionResult.Stay
        }
    }

    /** MediaStore query filtered by display name; capped rows for snappiness. */
    private fun queryFiles(term: String, filter: FileTypes.Category?): List<FoundFile> {
        val resolver = context.contentResolver
        val collection = filesCollection()
        val projection = buildList {
            add(MediaStore.Files.FileColumns._ID)
            add(MediaStore.Files.FileColumns.DISPLAY_NAME)
            add(MediaStore.Files.FileColumns.MIME_TYPE)
            add(MediaStore.Files.FileColumns.SIZE)
            add(MediaStore.Files.FileColumns.DATE_ADDED)
            if (Build.VERSION.SDK_INT >= 29) {
                add(MediaStore.Files.FileColumns.RELATIVE_PATH)
            }
        }.toTypedArray()

        val selection = "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ? ESCAPE '\\'"
        val args = arrayOf("%${escapeLike(term)}%")
        val order = "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"

        val rows = mutableListOf<FoundFile>()
        return runCatching {
            resolver.query(collection, projection, selection, args, order)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                val sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                val pathCol =
                    if (Build.VERSION.SDK_INT >= 29) {
                        cursor.getColumnIndex(MediaStore.Files.FileColumns.RELATIVE_PATH)
                    } else {
                        -1
                    }
                while (cursor.moveToNext() && rows.size < QUERY_CAP) {
                    val name = cursor.getString(nameCol) ?: continue
                    val category = FileTypes.categoryFor(
                        name,
                        if (mimeCol >= 0) cursor.getString(mimeCol) else null,
                    )
                    if (filter != null && category != filter) continue
                    val id = cursor.getLong(idCol)
                    rows.add(
                        FoundFile(
                            uri = ContentUris.withAppendedId(collection, id),
                            name = name,
                            mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null,
                            size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L,
                            folder = if (pathCol >= 0) cursor.getString(pathCol) else null,
                        ),
                    )
                }
            }
            rows
        }.getOrDefault(emptyList())
    }

    /** When only a filter is given ("file photo"), list newest of that kind. */
    private fun recentOf(filter: FileTypes.Category): List<FoundFile> {
        val resolver = context.contentResolver
        val collection = filesCollection()
        val projection = buildList {
            add(MediaStore.Files.FileColumns._ID)
            add(MediaStore.Files.FileColumns.DISPLAY_NAME)
            add(MediaStore.Files.FileColumns.MIME_TYPE)
            add(MediaStore.Files.FileColumns.SIZE)
            add(MediaStore.Files.FileColumns.DATE_ADDED)
            if (Build.VERSION.SDK_INT >= 29) {
                add(MediaStore.Files.FileColumns.RELATIVE_PATH)
            }
        }.toTypedArray()
        val order = "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"

        val rows = mutableListOf<FoundFile>()
        return runCatching {
            resolver.query(collection, projection, null, null, order)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                val sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                val pathCol =
                    if (Build.VERSION.SDK_INT >= 29) {
                        cursor.getColumnIndex(MediaStore.Files.FileColumns.RELATIVE_PATH)
                    } else {
                        -1
                    }
                while (cursor.moveToNext() && rows.size < MAX_RESULTS) {
                    val name = cursor.getString(nameCol) ?: continue
                    val category = FileTypes.categoryFor(
                        name,
                        if (mimeCol >= 0) cursor.getString(mimeCol) else null,
                    )
                    if (category != filter) continue
                    val id = cursor.getLong(idCol)
                    rows.add(
                        FoundFile(
                            uri = ContentUris.withAppendedId(collection, id),
                            name = name,
                            mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null,
                            size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L,
                            folder = if (pathCol >= 0) cursor.getString(pathCol) else null,
                        ),
                    )
                }
            }
            rows
        }.getOrDefault(emptyList())
    }

    private fun filesCollection(): Uri =
        if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Files.getContentUri("external")
        }

    private fun escapeLike(value: String): String =
        value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    private companion object {
        const val QUERY_CAP = 80
        const val MAX_RESULTS = 15
        const val MIN_PLAIN_QUERY = 3
    }
}
