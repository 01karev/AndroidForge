package com.profapps.quicklaunch.ui.settings

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.profapps.quicklaunch.QuickLaunchApp
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.data.QuickLaunchSettings
import com.profapps.quicklaunch.data.RecentsRepository
import com.profapps.quicklaunch.data.SettingsRepository
import com.profapps.quicklaunch.data.ThemeMode
import com.profapps.quicklaunch.data.WebEngine
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Control-center state. Thin on purpose: the source of truth is the settings
 * repository; the VM mirrors derived permission states that depend on the OS.
 * Dependencies are injected so the core logic is unit-testable on the JVM.
 */
class SettingsViewModel(
    private val settingsRepo: SettingsRepository,
    private val recentsRepo: RecentsRepository,
    private val checker: PermissionChecker,
) : ViewModel() {

    constructor(application: Application) : this(
        settingsRepo = (application as QuickLaunchApp).container.settingsRepository,
        recentsRepo = (application as QuickLaunchApp).container.recentsRepository,
        checker = AndroidPermissionChecker(application),
    )

    val settings: StateFlow<QuickLaunchSettings> = settingsRepo.settings

    var overlayPermissionGranted by mutableStateOf(false)
        private set
    var contactsPermissionGranted by mutableStateOf(false)
        private set
    var notificationPermissionGranted by mutableStateOf(true)
        private set
    var filesPermissionGranted by mutableStateOf(false)
        private set
    var showPermissionBanner by mutableStateOf(false)
        private set
    var assistantRoleHeld by mutableStateOf(false)
        private set

    init {
        refresh()
    }

    /** Re-reads OS permission state; call when returning from system settings. */
    fun refresh() {
        overlayPermissionGranted = checker.isOverlayGranted()
        contactsPermissionGranted = checker.isContactsGranted()
        notificationPermissionGranted = checker.isNotificationsGranted()
        filesPermissionGranted = checker.isFilesGranted()
        assistantRoleHeld = checker.isAssistantRoleHeld()
    }

    fun highlightPermissionIssue() {
        showPermissionBanner = true
    }

    fun dismissPermissionBanner() {
        showPermissionBanner = false
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsRepo.setThemeMode(mode) }
    }

    fun setPanelOpacity(value: Float) {
        viewModelScope.launch { settingsRepo.setPanelOpacity(value) }
    }

    fun setCompactMode(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setCompactMode(enabled) }
    }

    fun setAnimationsEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setAnimationsEnabled(enabled) }
    }

    fun setWebEngine(engine: WebEngine) {
        viewModelScope.launch { settingsRepo.setWebEngine(engine) }
    }

    fun setProviderEnabled(id: String, enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setProviderEnabled(id, enabled) }
    }

    fun setNotificationTrigger(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.setNotificationTriggerEnabled(enabled)
        }
    }

    fun setBubbleTrigger(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.setBubbleTriggerEnabled(enabled)
        }
    }

    fun setRecentsEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setRecentsEnabled(enabled) }
    }
    fun clearRecents() {
        viewModelScope.launch {
            recentsRepo.clear()
        }
    }

    /** Stable provider metadata for the settings list. */
    data class ProviderInfo(
        val id: String,
        val nameRes: Int,
        val descriptionRes: Int,
    )

    companion object {
        val PROVIDERS = listOf(
            ProviderInfo(ProviderIds.APPS, com.profapps.quicklaunch.R.string.provider_apps, com.profapps.quicklaunch.R.string.provider_apps_desc),
            ProviderInfo(ProviderIds.CALCULATOR, com.profapps.quicklaunch.R.string.provider_calculator, com.profapps.quicklaunch.R.string.provider_calculator_desc),
            ProviderInfo(ProviderIds.CONVERSION, com.profapps.quicklaunch.R.string.provider_conversion, com.profapps.quicklaunch.R.string.provider_conversion_desc),
            ProviderInfo(ProviderIds.FILES, com.profapps.quicklaunch.R.string.provider_files, com.profapps.quicklaunch.R.string.provider_files_desc),
            ProviderInfo(ProviderIds.WEB, com.profapps.quicklaunch.R.string.provider_web, com.profapps.quicklaunch.R.string.provider_web_desc),
            ProviderInfo(ProviderIds.CONTACTS, com.profapps.quicklaunch.R.string.provider_contacts, com.profapps.quicklaunch.R.string.provider_contacts_desc),
            ProviderInfo(ProviderIds.SETTINGS, com.profapps.quicklaunch.R.string.provider_settings, com.profapps.quicklaunch.R.string.provider_settings_desc),
            ProviderInfo(ProviderIds.CLIPBOARD, com.profapps.quicklaunch.R.string.provider_clipboard, com.profapps.quicklaunch.R.string.provider_clipboard_desc),
            ProviderInfo(ProviderIds.TORCH, com.profapps.quicklaunch.R.string.provider_torch, com.profapps.quicklaunch.R.string.provider_torch_desc),
            ProviderInfo(ProviderIds.QUICK_INFO, com.profapps.quicklaunch.R.string.provider_quick_info, com.profapps.quicklaunch.R.string.provider_quick_info_desc),
        )
    }
}

/** OS permission checks, injectable for tests. */
interface PermissionChecker {
    fun isOverlayGranted(): Boolean
    fun isContactsGranted(): Boolean
    fun isNotificationsGranted(): Boolean
    fun isFilesGranted(): Boolean

    /** Default off so JVM test fakes need no Android role APIs. */
    fun isAssistantRoleHeld(): Boolean = false
}

/** Real implementation backed by the Android permission APIs. */
class AndroidPermissionChecker(private val context: android.content.Context) : PermissionChecker {
    override fun isOverlayGranted(): Boolean =
        com.profapps.quicklaunch.overlay.OverlayController.isPermissionGranted(context)

    override fun isContactsGranted(): Boolean =
        androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.READ_CONTACTS,
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

    override fun isNotificationsGranted(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < 33) return true
        return androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.POST_NOTIFICATIONS,
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    /** Media permissions used by the file search provider. */
    override fun isFilesGranted(): Boolean {
        val sdk = android.os.Build.VERSION.SDK_INT
        val granted = { permission: String ->
            androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                permission,
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        return if (sdk >= 33) {
            granted(android.Manifest.permission.READ_MEDIA_IMAGES) ||
                granted(android.Manifest.permission.READ_MEDIA_VIDEO) ||
                granted(android.Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            granted(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    override fun isAssistantRoleHeld(): Boolean =
        com.profapps.quicklaunch.triggers.assist.AssistantRoleHelper.isDefaultAssistant(context)
}
