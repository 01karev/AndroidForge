package com.profapps.quicklaunch

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.profapps.quicklaunch.overlay.OverlayController
import com.profapps.quicklaunch.triggers.NotificationTrigger
import com.profapps.quicklaunch.triggers.assist.AssistantRoleHelper
import com.profapps.quicklaunch.ui.overlay.InAppPaletteScreen
import com.profapps.quicklaunch.ui.settings.SettingsScreen
import com.profapps.quicklaunch.ui.settings.SettingsViewModel
import com.profapps.quicklaunch.ui.theme.QuickLaunchTheme

/**
 * The "normal" app screen: a control center for triggers, appearance,
 * providers and privacy. Also hosts the in-app palette used as a fallback and
 * as the "test" surface when the overlay permission is missing.
 */
class MainActivity : ComponentActivity() {

    private lateinit var viewModel: SettingsViewModel

    private var showInAppPalette by mutableStateOf(false)
    private var prefillQuery by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        viewModel = SettingsViewModel(application)

        setContent {
            val settings by viewModel.settings.collectAsState()
            QuickLaunchTheme(themeMode = settings.themeMode) {
                if (showInAppPalette) {
                    InAppPaletteScreen(
                        onClose = { showInAppPalette = false },
                        initialQuery = prefillQuery,
                    )
                } else {
                    SettingsScreen(
                        viewModel = viewModel,
                        onTestOverlay = { onTestQuickLaunch() },
                    )
                }
            }
        }

        handleIntent(intent)
        requestNotificationPermissionIfNeeded()
        maybePromptForAssistantRoleOnce()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        when {
            intent.getBooleanExtra(EXTRA_MISSING_OVERLAY_PERMISSION, false) -> {
                // The overlay permission is missing; the settings screen shows
                // an explanatory banner with a direct route to Android settings.
                viewModel.highlightPermissionIssue()
            }
            intent.action == ACTION_OPEN_OVERLAY ||
                intent.getBooleanExtra(EXTRA_OPEN_OVERLAY, false) -> {
                if (OverlayController.isPermissionGranted(this)) {
                    OverlayController.show(this)
                } else {
                    viewModel.highlightPermissionIssue()
                    showInAppPalette = true
                }
            }
        }
        // Shared text ("Share to Quick Launch") or a widget prefill: open the
        // in-app palette with the text already typed in and searching.
        val prefill = intent.getStringExtra(EXTRA_PREFILL_QUERY)
        if (!prefill.isNullOrBlank()) {
            showInAppPalette = true
            prefillQuery = prefill
        }
    }

    private fun onTestQuickLaunch() {
        if (OverlayController.isPermissionGranted(this)) {
            OverlayController.show(this)
        } else {
            showInAppPalette = true
        }
    }

    /**
     * "Make it already default" as far as Android allows: no app can silently
     * assign itself the assistant role (it is a user-protected setting), but
     * we can show the ONE-TAP system dialog ("Set Quick Launch as your
     * assistant?") automatically, exactly once per install. After accepting,
     * every assist gesture — swipe up and hold / long-press home, and
     * long-press power where the device maps it to the assistant — opens the
     * palette in place of Google Assistant.
     */
    private fun maybePromptForAssistantRoleOnce() {
        val prefs = getSharedPreferences(ASSISTANT_PROMPT_PREFS, MODE_PRIVATE)
        if (prefs.getBoolean(ASSISTANT_PROMPTED_KEY, false)) return
        prefs.edit().putBoolean(ASSISTANT_PROMPTED_KEY, true).apply()
        if (AssistantRoleHelper.isDefaultAssistant(this)) return
        // Show the system role dialog slightly later so it does not collide
        // with the notification permission dialog that Android may also show.
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            runCatching {
                AssistantRoleHelper.requestAssistantRole(this)
            }
        }, 1_200)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < 33) return
        val permission = Manifest.permission.POST_NOTIFICATIONS
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) return
        requestPermissions(arrayOf(permission), NOTIF_PERMISSION_REQUEST)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NOTIF_PERMISSION_REQUEST) {
            viewModel.refresh()
            NotificationTrigger.ensureChannels(this)
        }
    }

    companion object {
        const val EXTRA_MISSING_OVERLAY_PERMISSION = "missing_overlay_permission"
        const val EXTRA_OPEN_OVERLAY = "open_overlay"
        const val EXTRA_PREFILL_QUERY = "prefill_query"
        const val ACTION_OPEN_OVERLAY = "com.profapps.quicklaunch.action.OPEN_OVERLAY"
        private const val NOTIF_PERMISSION_REQUEST = 1001
        private const val ASSISTANT_PROMPT_PREFS = "assistant_prompt"
        private const val ASSISTANT_PROMPTED_KEY = "prompted_once"
    }
}
