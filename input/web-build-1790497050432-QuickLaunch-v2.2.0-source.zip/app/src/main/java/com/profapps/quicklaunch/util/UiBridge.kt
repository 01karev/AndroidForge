package com.profapps.quicklaunch.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/** Small helpers for clipboard access and main-thread-safe toasts. */
object UiBridge {

    fun copy(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
        runCatching { cm.setPrimaryClip(ClipData.newPlainText("Quick Launch", text)) }
    }

    /** Best-effort read; returns null on Android 10+ when we lack focus. */
    fun readClipboardText(context: Context): String? = runCatching {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
        if (!cm.hasPrimaryClip()) return null
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        clip.getItemAt(0).coerceToText(context)?.toString()?.takeIf { it.isNotBlank() }
    }.getOrNull()

    fun toast(context: Context, message: String) {
        val show = {
            try {
                Toast.makeText(context.applicationContext, message, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                // Toasts can fail on some OEMs from service contexts; ignore.
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) show() else Handler(Looper.getMainLooper()).post(show)
    }
}
