package com.profapps.quicklaunch.search

/**
 * A KRunner-style "runner". Providers receive the current query and return a
 * list of results asynchronously. Implementations must be safe to cancel:
 * the engine cancels in-flight searches whenever the query changes.
 */
interface SearchProvider {
    /** Stable identifier matching [com.profapps.quicklaunch.data.ProviderIds]. */
    val id: String

    /** Human-readable name shown in settings. */
    val displayName: String

    /**
     * Search for the given query. Return an empty list when nothing matches.
     * Implementations should avoid blocking work on the calling context and
     * wrap their own IO in the appropriate dispatcher.
     */
    suspend fun search(query: SearchQuery): List<SearchResult>
}
