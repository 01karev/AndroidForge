package com.profapps.quicklaunch.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * On-device history of executed results. Nothing here ever leaves the device;
 * it powers the empty-state "Recent" list and ranking boosts.
 *
 * Encoding: entries separated by U+0001, fields by U+001F. Both are control
 * characters that cannot appear in app labels or queries, so no escaping
 * library is needed.
 */
class RecentsRepository(private val dataStore: DataStore<Preferences>) {

    private val key = stringPreferencesKey("recents")

    private companion object {
        const val ENTRY_SEP = '\u0001'
        const val FIELD_SEP = '\u001f'
        const val MAX_ENTRIES = 12
        const val ONE_HOUR_MS = 60L * 60 * 1000
        const val ONE_DAY_MS = 24L * 60 * 60 * 1000
    }

    val recents: Flow<List<RecentEntry>> = dataStore.data.map { prefs ->
        decode(prefs[key] ?: "")
    }

    suspend fun record(entry: RecentEntry) {
        // History is a nice-to-have: a failed write (disk full, transient IO
        // error) must never crash the palette, so the edit is best-effort.
        runCatching {
            dataStore.edit { prefs ->
                val existing = decode(prefs[key] ?: "").toMutableList()
                existing.removeAll { it.id == entry.id }
                existing.add(0, entry.copy(timestamp = System.currentTimeMillis()))
                while (existing.size > MAX_ENTRIES) existing.removeAt(existing.size - 1)
                prefs[key] = encode(existing)
            }
        }
    }

    suspend fun clear() {
        runCatching { dataStore.edit { it.remove(key) } }
    }

    /** Launch/usage counts per package (or per result id for non-app results). */
    suspend fun usageCounts(): Map<String, Int> {
        val list = runCatching { recents.first() }.getOrDefault(emptyList())
        val counts = mutableMapOf<String, Int>()
        for (entry in list) {
            val k = entry.packageName ?: entry.id
            counts[k] = (counts[k] ?: 0) + 1
        }
        return counts
    }

    /**
     * Deterministic ranking boosts per package/id derived from history:
     * recency (last hour > last day) plus a small frequency term.
     */
    suspend fun rankingBoosts(): Map<String, Float> {
        val list = runCatching { recents.first() }.getOrDefault(emptyList())
        if (list.isEmpty()) return emptyMap()
        val now = System.currentTimeMillis()
        val out = mutableMapOf<String, Float>()
        for ((index, entry) in list.withIndex()) {
            val key = entry.packageName ?: entry.id
            val age = now - entry.timestamp
            val recency = when {
                age < ONE_HOUR_MS -> 0.15f
                age < ONE_DAY_MS -> 0.08f
                else -> 0f
            }
            val frequency = (list.size - index).coerceAtLeast(0) * 0.004f
            out[key] = ((out[key] ?: 0f) + recency + frequency).coerceAtMost(0.25f)
        }
        return out
    }

    private fun encode(entries: List<RecentEntry>): String =
        entries.joinToString(ENTRY_SEP.toString()) { e ->
            listOf(
                e.id,
                e.title,
                e.subtitle ?: "",
                e.packageName ?: "",
                e.kind,
                e.timestamp.toString(),
                e.payload,
            ).joinToString(FIELD_SEP.toString())
        }

    private fun decode(raw: String): List<RecentEntry> {
        if (raw.isBlank()) return emptyList()
        return raw.split(ENTRY_SEP).mapNotNull { chunk ->
            val f = chunk.split(FIELD_SEP)
            if (f.size < 6) return@mapNotNull null
            runCatching {
                RecentEntry(
                    id = f[0],
                    title = f[1],
                    subtitle = f[2].ifEmpty { null },
                    packageName = f[3].ifEmpty { null },
                    kind = f[4],
                    timestamp = f[5].toLong(),
                    payload = if (f.size > 6) f[6] else "",
                )
            }.getOrNull()
        }
    }
}
