package com.profapps.quicklaunch.providers

import android.content.Context
import com.profapps.quicklaunch.R
import com.profapps.quicklaunch.data.ProviderIds
import com.profapps.quicklaunch.providers.conversion.UnitConverter
import com.profapps.quicklaunch.search.ActionResult
import com.profapps.quicklaunch.search.CommandHint
import com.profapps.quicklaunch.search.ResultCategory
import com.profapps.quicklaunch.search.ResultIcon
import com.profapps.quicklaunch.search.SearchProvider
import com.profapps.quicklaunch.search.SearchQuery
import com.profapps.quicklaunch.search.SearchResult
import com.profapps.quicklaunch.util.UiBridge

/**
 * Offline unit conversions: "10 km to miles", "5kg in lb", "100 c to f".
 * Static tables only — live data such as currency rates is deliberately not
 * claimed or supported.
 */
class UnitConversionProvider(private val context: Context) : SearchProvider {

    override val id = ProviderIds.CONVERSION
    override val displayName = "Unit conversion"

    override suspend fun search(query: SearchQuery): List<SearchResult> {
        val expression: String = when (val hint = query.hint) {
            is CommandHint.Convert -> hint.expression
            else -> query.raw
        }
        if (!UnitConverter.looksLikeConversion(expression)) return emptyList()

        val result = UnitConverter.convert(expression) as? UnitConverter.ConversionResult.Success
            ?: return emptyList()

        return listOf(
            SearchResult(
                id = "convert:${expression.lowercase()}",
                title = result.outputDisplay,
                subtitle = result.inputDisplay,
                icon = ResultIcon.ResourceIcon(R.drawable.ic_convert),
                score = if (query.hint is CommandHint.Convert) 1.0f else 0.96f,
                category = ResultCategory.CONVERSIONS,
                copyText = result.outputDisplay,
                action = {
                    UiBridge.copy(context, result.outputDisplay)
                    UiBridge.toast(context, context.getString(R.string.copied))
                    ActionResult.Stay
                },
            )
        )
    }
}
