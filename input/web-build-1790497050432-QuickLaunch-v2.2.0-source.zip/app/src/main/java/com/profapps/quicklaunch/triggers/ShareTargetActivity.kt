package com.profapps.quicklaunch.triggers

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.profapps.quicklaunch.MainActivity

/**
 * Share-to-QuickLaunch: any "share" from another app lands here and the text
 * is dropped straight into the in-app palette so it can be searched, copied,
 * opened as a URL or passed to the web provider.
 */
class ShareTargetActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = when (intent?.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_SEND_MULTIPLE ->
                intent.getStringArrayListExtra(Intent.EXTRA_TEXT)?.joinToString(" ")
            else -> null
        }
        if (text.isNullOrBlank()) {
            finish()
            return
        }
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_PREFILL_QUERY, text.take(500))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        finish()
    }
}
