package com.profapps.quicklaunch.util

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.util.LruCache
import androidx.core.graphics.drawable.toBitmap

/**
 * Resolves installed-app icons with a small LRU cache. Called from IO
 * dispatchers only; the returned Bitmap is safe to hand to Compose.
 */
object IconLoader {

    private const val TARGET_SIZE_PX = 108
    private val cache = LruCache<String, Bitmap>(160)

    fun loadAppIcon(context: Context, component: ComponentName): Bitmap? {
        val key = component.flattenToString()
        cache.get(key)?.let { return it }
        return runCatching {
            val drawable = context.packageManager.getActivityIcon(component)
            val bitmap = drawable.toBitmap(TARGET_SIZE_PX, TARGET_SIZE_PX)
            cache.put(key, bitmap)
            bitmap
        }.getOrNull()
    }

    /** Evicts everything — called when the package list changes. */
    fun clearCache() {
        cache.evictAll()
    }
}
