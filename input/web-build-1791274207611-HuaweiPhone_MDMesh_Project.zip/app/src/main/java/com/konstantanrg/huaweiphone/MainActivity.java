package com.konstantanrg.huaweiphone;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(
                "com.huawei.contacts",
                "com.android.contacts.activities.DialtactsActivity"
        ));
        try {
            startActivity(intent);
        } finally {
            finish();
        }
    }
}
