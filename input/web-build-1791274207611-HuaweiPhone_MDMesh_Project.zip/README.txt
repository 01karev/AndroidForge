Huawei Phone — tiny launcher APK for MDMesh.

It shows a "Телефон" launcher icon and opens the stock Huawei dialer:
com.huawei.contacts/com.android.contacts.activities.DialtactsActivity

No permissions. Does not become the default dialer.
Build as a debug APK.
