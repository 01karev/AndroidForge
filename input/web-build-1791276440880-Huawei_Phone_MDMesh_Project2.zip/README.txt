Huawei Phone / MDMesh test APK source

Package: com.konstantanrg.phone
App label: Телефон
Target: Huawei Android/EMUI 10-12

Build: AndroidForge -> upload this ZIP -> build variant release or debug.
The launcher activity opens the system dialer via ACTION_DIAL and exits.
No network permissions, no external dependencies, no NDK.
