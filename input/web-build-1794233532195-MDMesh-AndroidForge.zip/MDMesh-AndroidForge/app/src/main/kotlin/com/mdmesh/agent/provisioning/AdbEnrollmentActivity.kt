package com.mdmesh.agent.provisioning

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.mdmesh.core.config.ServerConfigStore
import com.mdmesh.core.store.DeviceIdStore
import com.mdmesh.core.store.EnrollTokenStore
import com.mdmesh.core.sync.CheckInWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AdbEnrollmentActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val ctx = applicationContext
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

        if (!dpm.isDeviceOwnerApp(packageName)) {
            finishWithError("Agent is not Device Owner")
            return
        }

        val token = intent.getStringExtra("enroll_token")?.trim()
        val serverUrl = intent.getStringExtra("server_url")?.trim()

        if (token.isNullOrBlank() || serverUrl.isNullOrBlank()
            || !serverUrl.startsWith("https://")
        ) {
            finishWithError("Missing token or HTTPS server URL")
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (DeviceIdStore(ctx).current()?.isNotBlank() == true) {
                    throw IllegalStateException("Device is already enrolled")
                }

                ServerConfigStore(ctx).save(serverUrl)
                EnrollTokenStore(ctx).save(token)
                CheckInWorker.scheduleNow(ctx)

                runOnUiThread {
                    Toast.makeText(
                        this@AdbEnrollmentActivity,
                        "Enrollment started",
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                }
            } catch (e: Exception) {
                Log.e("AdbEnrollment", "Enrollment initialization failed", e)
                runOnUiThread {
                    Toast.makeText(
                        this@AdbEnrollmentActivity,
                        e.message ?: "Enrollment initialization failed",
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                }
            }
        }
    }

    private fun finishWithError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        finish()
    }
}
