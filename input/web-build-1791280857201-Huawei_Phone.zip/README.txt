Huawei Phone MDMesh project v1.1
Package: com.konstantanrg.phone
Label: Телефон
Version: 1.1 (versionCode 2)
Includes a telephone handset launcher icon. Launcher opens the system dialer via ACTION_DIAL.
